import type { GameState } from '../engine/session'
import { migrate, parseGameRecord, parseSession, SCHEMA_VERSION } from './schema'
import type { GameRecord, StoredHistory, StoredSession } from './schema'

export interface StorageLike {
  getItem(key: string): string | null
  setItem(key: string, value: string): void
  removeItem(key: string): void
}

export const KEYS = {
  current: 'midnight-chess:current',
  history: 'midnight-chess:history',
} as const

export type SaveResult = { ok: true } | { ok: false; error: string }

export type LoadCurrent =
  | { status: 'empty' }
  | { status: 'ok'; state: GameState; archived: boolean }
  /** Data existed but could not be used; it was set aside and nothing was lost silently. */
  | { status: 'invalid'; message: string }

export interface LoadHistory {
  games: GameRecord[]
  /** Human-readable problems found while loading (dropped records, set-aside data). */
  warnings: string[]
}

/** Returns window.localStorage, or null when the browser refuses access. */
export function browserStorage(): StorageLike | null {
  try {
    const s = globalThis.localStorage
    const probe = '__midnight-chess:probe'
    s.setItem(probe, '1')
    s.removeItem(probe)
    return s
  } catch {
    return null
  }
}

const describe = (e: unknown) => (e instanceof Error ? e.message : String(e))

export class Persistence {
  constructor(
    private readonly storage: StorageLike | null,
    private readonly now: () => Date = () => new Date(),
  ) {}

  get available(): boolean {
    return this.storage !== null
  }

  private write(key: string, value: unknown): SaveResult {
    if (!this.storage) return { ok: false, error: 'Armazenamento indisponível neste navegador.' }
    try {
      this.storage.setItem(key, JSON.stringify(value))
      return { ok: true }
    } catch (e) {
      return { ok: false, error: `Não foi possível salvar: ${describe(e)}` }
    }
  }

  /** First time an older-format file is read, keep an untouched copy next to it. */
  private backupOnce(key: string, raw: string, version: unknown) {
    if (typeof version !== 'number' || version >= SCHEMA_VERSION) return
    const tag = `backup-v${version}`
    try {
      if (this.storage && this.storage.getItem(`${key}:${tag}`) === null) this.storage.setItem(`${key}:${tag}`, raw)
    } catch {
      /* best effort */
    }
  }

  /** Keeps unreadable or newer-format data under a side key so it is never overwritten blindly. */
  private setAside(key: string, raw: string, tag: string) {
    try {
      this.storage?.setItem(`${key}:${tag}`, raw)
    } catch {
      /* best effort */
    }
  }

  private readJson(key: string): { status: 'empty' } | { status: 'ok'; data: Record<string, unknown>; raw: string } | { status: 'bad'; raw: string; reason: string } {
    if (!this.storage) return { status: 'empty' }
    let raw: string | null
    try {
      raw = this.storage.getItem(key)
    } catch (e) {
      return { status: 'bad', raw: '', reason: describe(e) }
    }
    if (raw === null) return { status: 'empty' }
    try {
      const parsed: unknown = JSON.parse(raw)
      if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
        return { status: 'bad', raw, reason: 'formato inesperado' }
      }
      return { status: 'ok', data: parsed as Record<string, unknown>, raw }
    } catch {
      return { status: 'bad', raw, reason: 'JSON corrompido' }
    }
  }

  // ---- game in progress -------------------------------------------------

  loadCurrent(): LoadCurrent {
    const read = this.readJson(KEYS.current)
    if (read.status === 'empty') return { status: 'empty' }
    if (read.status === 'bad') return this.reject(KEYS.current, read.raw, 'corrupt', read.reason)
    const migrated = migrate(read.data)
    if (!migrated.ok) return this.reject(KEYS.current, read.raw, `v${String(read.data.version)}`, migrated.error)
    const parsed = parseSession(migrated.value)
    if (!parsed.ok) return this.reject(KEYS.current, read.raw, 'corrupt', parsed.error)
    this.backupOnce(KEYS.current, read.raw, read.data.version)
    return { status: 'ok', state: parsed.value, archived: read.data.archived === true }
  }

  private reject(key: string, raw: string, tag: string, reason: string): LoadCurrent {
    this.setAside(key, raw, tag)
    try {
      this.storage?.removeItem(key)
    } catch {
      /* best effort */
    }
    return { status: 'invalid', message: `A partida salva não pôde ser recuperada (${reason}).` }
  }

  saveCurrent(state: GameState, archived = false): SaveResult {
    const payload: StoredSession = {
      version: SCHEMA_VERSION,
      savedAt: this.now().toISOString(),
      archived,
      session: {
        id: state.id,
        startedAt: state.startedAt,
        players: state.players,
        moves: state.moves,
        redo: state.redo,
        orientation: state.orientation,
        manualOutcome: state.manualOutcome,
        clock: state.clock,
      },
    }
    return this.write(KEYS.current, payload)
  }

  clearCurrent(): SaveResult {
    if (!this.storage) return { ok: true }
    try {
      this.storage.removeItem(KEYS.current)
      return { ok: true }
    } catch (e) {
      return { ok: false, error: `Não foi possível limpar: ${describe(e)}` }
    }
  }

  // ---- finished games ---------------------------------------------------

  loadHistory(): LoadHistory {
    const read = this.readJson(KEYS.history)
    if (read.status === 'empty') return { games: [], warnings: [] }
    if (read.status === 'bad') {
      this.setAside(KEYS.history, read.raw, 'corrupt')
      return { games: [], warnings: [`O histórico salvo estava ilegível (${read.reason}) e foi guardado à parte.`] }
    }
    const migrated = migrate(read.data)
    if (!migrated.ok) {
      this.setAside(KEYS.history, read.raw, `v${String(read.data.version)}`)
      return { games: [], warnings: [`O histórico salvo não pôde ser lido (${migrated.error}) e foi guardado à parte.`] }
    }
    const list = (migrated.value as unknown as StoredHistory).games
    if (!Array.isArray(list)) return { games: [], warnings: ['O histórico salvo tinha formato inesperado.'] }
    this.backupOnce(KEYS.history, read.raw, read.data.version)
    const games: GameRecord[] = []
    const seen = new Set<string>()
    let dropped = 0
    for (const item of list) {
      const parsed = parseGameRecord(item)
      if (parsed.ok && !seen.has(parsed.value.id)) {
        seen.add(parsed.value.id)
        games.push(parsed.value)
      } else {
        dropped++
      }
    }
    const warnings = dropped > 0 ? [`${dropped} partida(s) do histórico estavam inválidas e foram ignoradas.`] : []
    return { games, warnings }
  }

  private saveHistory(games: GameRecord[]): SaveResult {
    const payload: StoredHistory = { version: SCHEMA_VERSION, games }
    return this.write(KEYS.history, payload)
  }

  /** Inserts or replaces by id, so restoring a session can never duplicate a game. */
  upsertGame(record: GameRecord): SaveResult {
    const { games } = this.loadHistory()
    const next = games.filter((g) => g.id !== record.id)
    next.push(record)
    next.sort((a, b) => b.endedAt.localeCompare(a.endedAt))
    return this.saveHistory(next)
  }

  deleteGame(id: string): SaveResult {
    const { games } = this.loadHistory()
    return this.saveHistory(games.filter((g) => g.id !== id))
  }
}
