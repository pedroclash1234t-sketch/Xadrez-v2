import type { Color, Square } from './chessLib'

export type PromotionPiece = 'q' | 'r' | 'b' | 'n'

/** One half-move, enough to rebuild a game from the standard start position. */
export interface MoveRecord {
  san: string
  from: Square
  to: Square
  promotion?: PromotionPiece
}

export type GameResult = '1-0' | '0-1' | '1/2-1/2'

export type EndReason =
  | 'checkmate'
  | 'stalemate'
  | 'insufficient-material'
  | 'fivefold-repetition'
  | 'seventy-five-move'
  | 'resignation'
  | 'agreement'
  | 'threefold-claimed'
  | 'fifty-move-claimed'
  | 'timeout'
  | 'timeout-insufficient'
  /** Imported game whose result comes from the PGN (resignation, time, agreement...: not checkable). */
  | 'recorded'

export interface Outcome {
  result: GameResult
  reason: EndReason
  winner?: Color
  /** Who ran out of time (only for 'timeout' and 'timeout-insufficient'). */
  flagged?: Color
}

export const AUTOMATIC_REASONS: readonly EndReason[] = [
  'checkmate',
  'stalemate',
  'insufficient-material',
  'fivefold-repetition',
  'seventy-five-move',
]

export const MANUAL_REASONS: readonly EndReason[] = [
  'resignation',
  'agreement',
  'threefold-claimed',
  'fifty-move-claimed',
  'timeout',
  'timeout-insufficient',
  'recorded',
]

export const opposite = (c: Color): Color => (c === 'w' ? 'b' : 'w')
