import { clockAfterMove, createClock, stopClock, timeLeft, allowsManualPause } from './clock'
import type { ClockState, PauseKind, TimeControl } from './clock'
import { analyzeMoves, hasInsufficientMaterial, needsPromotion, replay } from './position'
import type { Analysis } from './position'
import type { Color, Square } from './chessLib'
import { opposite } from './types'
import type { MoveRecord, Outcome, PromotionPiece } from './types'

export interface Players {
  w: string
  b: string
}

/**
 * Whole state of one game. Immutable: every operation returns a new object.
 * `moves` is the played line; `redo` holds undone moves (last item = next redo);
 * `viewIndex` is only the browsing cursor and never changes the game itself.
 * `manualOutcome` is any ending decided outside the board rules (resignation, agreement,
 * a claimed draw, a flag fall). `clock` is null in untimed games.
 */
export interface GameState {
  id: string
  startedAt: string
  players: Players
  moves: MoveRecord[]
  redo: MoveRecord[]
  viewIndex: number
  orientation: Color
  manualOutcome: Outcome | null
  clock: ClockState | null
}

export interface GameEnv {
  now(): Date
  newId(): string
}

export const DEFAULT_PLAYERS: Players = { w: 'Brancas', b: 'Pretas' }
export const MAX_NAME_LENGTH = 24

export function cleanName(raw: string, fallback: string): string {
  const name = raw.replace(/\s+/g, ' ').trim().slice(0, MAX_NAME_LENGTH)
  return name || fallback
}

export function createGame(
  env: GameEnv,
  players: Partial<Players> = {},
  orientation: Color = 'w',
  control: TimeControl | null = null,
): GameState {
  return {
    id: env.newId(),
    startedAt: env.now().toISOString(),
    players: {
      w: cleanName(players.w ?? '', DEFAULT_PLAYERS.w),
      b: cleanName(players.b ?? '', DEFAULT_PLAYERS.b),
    },
    moves: [],
    redo: [],
    viewIndex: 0,
    orientation,
    manualOutcome: null,
    clock: control ? createClock(control) : null,
  }
}

/** Standard start position, so the side to move follows from the number of half-moves. */
export const sideToMove = (s: GameState): Color => (s.moves.length % 2 === 0 ? 'w' : 'b')

/** Analysis of the live (last played) position. */
export const liveAnalysis = (s: GameState): Analysis => analyzeMoves(s.moves, s.moves.length)

/** Analysis of the position currently shown on the board. */
export const viewAnalysis = (s: GameState): Analysis => analyzeMoves(s.moves, s.viewIndex)

export const outcomeOf = (s: GameState): Outcome | null => s.manualOutcome ?? liveAnalysis(s).outcome

export const isFinished = (s: GameState): boolean => outcomeOf(s) !== null
export const isLive = (s: GameState): boolean => s.viewIndex === s.moves.length
export const isTimed = (s: GameState): boolean => s.clock !== null
export const isPaused = (s: GameState): boolean => s.clock?.paused != null
export const canPlay = (s: GameState): boolean => isLive(s) && !isFinished(s) && !isPaused(s)

/**
 * Timed games never offer undo/redo: taking a move back would hand time back, so the
 * clock could be cheated. Untimed games keep both.
 */
export const canUndo = (s: GameState): boolean => s.moves.length > 0 && !isFinished(s) && s.clock === null
export const canRedo = (s: GameState): boolean => s.redo.length > 0 && !isFinished(s) && s.clock === null

/**
 * A new game or a restart would let a player escape a timed game that is going badly, so
 * it is refused while a timed game is in progress (resign or claim a draw instead).
 */
export const canLeaveGame = (s: GameState): boolean => !(s.clock !== null && s.moves.length > 0 && !isFinished(s))

export type MoveError = 'illegal' | 'promotion-required' | 'game-over' | 'not-live' | 'paused' | 'time-over'

export interface MoveInput {
  from: Square
  to: Square
  promotion?: PromotionPiece
}

export type MoveResult = { ok: true; state: GameState } | { ok: false; error: MoveError }

function requireNow(now: number | undefined): number {
  if (now === undefined) throw new Error('Partidas com relógio exigem o instante atual (now).')
  return now
}

/** chess.js is the only authority: anything it rejects leaves the state untouched. */
export function playMove(state: GameState, input: MoveInput, now?: number): MoveResult {
  if (!isLive(state)) return { ok: false, error: 'not-live' }
  if (isFinished(state)) return { ok: false, error: 'game-over' }
  const clock = state.clock
  const mover = sideToMove(state)
  if (clock) {
    if (clock.paused) return { ok: false, error: 'paused' }
    const t = requireNow(now)
    if (clock.since !== null && timeLeft(clock, mover, mover, t) <= 0) return { ok: false, error: 'time-over' }
  }
  const { chess } = replay(state.moves)
  if (needsPromotion(chess, input.from, input.to) && !input.promotion) {
    return { ok: false, error: 'promotion-required' }
  }
  let played
  try {
    played = chess.move({ from: input.from, to: input.to, promotion: input.promotion })
  } catch {
    return { ok: false, error: 'illegal' }
  }
  if (!played) return { ok: false, error: 'illegal' }
  const record: MoveRecord = { san: played.san, from: played.from, to: played.to }
  if (played.promotion) record.promotion = played.promotion as PromotionPiece
  const moves = [...state.moves, record]
  const over = clock ? analyzeMoves(moves).outcome !== null : false
  const nextClock = clock ? clockAfterMove(clock, mover, state.moves.length === 0, over, requireNow(now)) : null
  return { ok: true, state: { ...state, moves, redo: [], viewIndex: moves.length, clock: nextClock } }
}

export function undo(state: GameState): GameState {
  if (!canUndo(state)) return state
  const moves = state.moves.slice(0, -1)
  const undone = state.moves[state.moves.length - 1]
  return { ...state, moves, redo: [...state.redo, undone], viewIndex: moves.length }
}

export function redo(state: GameState): GameState {
  if (!canRedo(state)) return state
  const next = state.redo[state.redo.length - 1]
  const moves = [...state.moves, next]
  return { ...state, moves, redo: state.redo.slice(0, -1), viewIndex: moves.length }
}

export type NavTarget = 'first' | 'prev' | 'next' | 'last' | number

export function navigate(state: GameState, target: NavTarget): GameState {
  const last = state.moves.length
  const raw =
    target === 'first' ? 0 : target === 'last' ? last : target === 'prev' ? state.viewIndex - 1 : target === 'next' ? state.viewIndex + 1 : target
  const viewIndex = Math.max(0, Math.min(last, Math.trunc(raw)))
  return viewIndex === state.viewIndex ? state : { ...state, viewIndex }
}

export const flip = (s: GameState): GameState => ({ ...s, orientation: opposite(s.orientation) })

/** Ends the game with an outcome decided outside the board rules, stopping the clock. */
function conclude(state: GameState, outcome: Outcome, now: number | undefined): GameState {
  const clock = state.clock && state.clock.since !== null ? stopClock(state.clock, sideToMove(state), requireNow(now)) : state.clock
  return { ...state, viewIndex: state.moves.length, manualOutcome: outcome, clock }
}

export function resign(state: GameState, color: Color, now?: number): GameState {
  if (isFinished(state)) return state
  const winner = opposite(color)
  return conclude(state, { result: winner === 'w' ? '1-0' : '0-1', reason: 'resignation', winner }, now)
}

export function agreeDraw(state: GameState, now?: number): GameState {
  if (isFinished(state)) return state
  return conclude(state, { result: '1/2-1/2', reason: 'agreement' }, now)
}

/** Draw claim under the threefold-repetition or 50-move rule, only when available. */
export function claimDraw(state: GameState, now?: number): GameState {
  if (isFinished(state)) return state
  const { claim } = liveAnalysis(state)
  if (!claim.threefold && !claim.fiftyMove) return state
  return conclude(state, { result: '1/2-1/2', reason: claim.threefold ? 'threefold-claimed' : 'fifty-move-claimed' }, now)
}

// ---- clock -------------------------------------------------------------------

/** Remaining time of `color` at `now`; null in untimed games. */
export function timeLeftOf(state: GameState, color: Color, now: number): number | null {
  return state.clock ? timeLeft(state.clock, sideToMove(state), color, now) : null
}

/** Side whose time has run out at `now`, if the clock is running and the game is on. */
export function flaggedSide(state: GameState, now: number): Color | null {
  const c = state.clock
  if (!c || c.since === null || c.paused || isFinished(state)) return null
  const turn = sideToMove(state)
  return timeLeft(c, turn, turn, now) <= 0 ? turn : null
}

/**
 * Applies a flag fall: the player out of time loses, unless the opponent could not checkmate
 * with the material left (then it is a draw).
 */
export function applyTimeout(state: GameState, now: number): GameState {
  const loser = flaggedSide(state, now)
  const c = state.clock
  if (!loser || !c) return state
  const winner = opposite(loser)
  const drawn = hasInsufficientMaterial(replay(state.moves).chess, winner)
  const outcome: Outcome = drawn
    ? { result: '1/2-1/2', reason: 'timeout-insufficient', flagged: loser }
    : { result: winner === 'w' ? '1-0' : '0-1', reason: 'timeout', winner, flagged: loser }
  return {
    ...state,
    viewIndex: state.moves.length,
    manualOutcome: outcome,
    clock: { ...c, remaining: { ...c.remaining, [loser]: 0 }, since: null },
  }
}

/**
 * Stops both clocks and hides nothing else. Manual pauses exist only in the slower modes;
 * automatic ones (app left the foreground) and restores are always allowed.
 * Before the first move no clock is running, so there is nothing to pause.
 */
export function pauseClock(state: GameState, now: number, kind: PauseKind): GameState {
  const c = state.clock
  if (!c || c.paused || isFinished(state) || state.moves.length === 0) return state
  if (kind === 'manual' && !allowsManualPause(c.control)) return state
  return { ...state, clock: { ...stopClock(c, sideToMove(state), now), paused: kind } }
}

export function resumeClock(state: GameState, now: number): GameState {
  const c = state.clock
  if (!c || !c.paused || isFinished(state)) return state
  return { ...state, clock: { ...c, paused: null, since: now } }
}

/**
 * A timed game loaded from storage comes back paused. The time between the last saved
 * event and the reopening is not charged to anyone.
 */
export function restoreClock(state: GameState): GameState {
  const c = state.clock
  if (!c || c.paused || isFinished(state) || state.moves.length === 0) return state
  return { ...state, clock: { ...c, since: null, paused: 'restore' } }
}

export const hasProgress = (s: GameState): boolean => s.moves.length > 0 && !isFinished(s)

export function fenAt(state: GameState, index: number): string {
  return analyzeMoves(state.moves, index).fen
}
