import type { Color } from './chessLib'

/** Fischer control: `baseMs` for the whole game plus `incrementMs` after each move. */
export interface TimeControl {
  baseMs: number
  incrementMs: number
}

/** Why the clock is stopped before the game is over. */
export type PauseKind = 'manual' | 'auto' | 'restore'

/**
 * Clock of one game. `remaining` is each side's time as of the last event (move, pause,
 * resume); the side to move is additionally charged `now - since` while `since` is set.
 * `since` is null when the clock is not running: before the first move, paused, or over.
 */
export interface ClockState {
  control: TimeControl
  remaining: Record<Color, number>
  since: number | null
  paused: PauseKind | null
}

export type TimeCategory = 'bullet' | 'blitz' | 'rapid' | 'classical'

export const CATEGORY_LABEL: Record<TimeCategory, string> = {
  bullet: 'Bullet',
  blitz: 'Blitz',
  rapid: 'Rápido',
  classical: 'Clássico',
}

export const LIMITS = { minBaseMin: 1, maxBaseMin: 180, maxIncrementSec: 60 } as const

export interface Preset {
  category: TimeCategory
  baseMin: number
  incrementSec: number
}

export const PRESETS: readonly Preset[] = [
  { category: 'bullet', baseMin: 1, incrementSec: 0 },
  { category: 'bullet', baseMin: 2, incrementSec: 1 },
  { category: 'blitz', baseMin: 3, incrementSec: 0 },
  { category: 'blitz', baseMin: 3, incrementSec: 2 },
  { category: 'blitz', baseMin: 5, incrementSec: 0 },
  { category: 'rapid', baseMin: 10, incrementSec: 0 },
  { category: 'rapid', baseMin: 15, incrementSec: 10 },
  { category: 'classical', baseMin: 30, incrementSec: 0 },
  { category: 'classical', baseMin: 60, incrementSec: 30 },
]

/** Whole minutes and seconds only; null when outside LIMITS. */
export function controlFrom(baseMin: number, incrementSec: number): TimeControl | null {
  if (!Number.isInteger(baseMin) || !Number.isInteger(incrementSec)) return null
  if (baseMin < LIMITS.minBaseMin || baseMin > LIMITS.maxBaseMin) return null
  if (incrementSec < 0 || incrementSec > LIMITS.maxIncrementSec) return null
  return { baseMs: baseMin * 60_000, incrementMs: incrementSec * 1000 }
}

export const sameControl = (a: TimeControl | null, b: TimeControl | null): boolean =>
  a === b || (!!a && !!b && a.baseMs === b.baseMs && a.incrementMs === b.incrementMs)

/** Same estimate lichess uses: base + 40 increments. Under 3 min bullet, 8 blitz, 25 rapid. */
export function categoryOf(c: TimeControl): TimeCategory {
  const estimatedSeconds = c.baseMs / 1000 + 40 * (c.incrementMs / 1000)
  if (estimatedSeconds < 180) return 'bullet'
  if (estimatedSeconds < 480) return 'blitz'
  if (estimatedSeconds < 1500) return 'rapid'
  return 'classical'
}

/** Manual pause exists only in the slower modes; see docs/RELOGIOS.md. */
export const allowsManualPause = (c: TimeControl): boolean => {
  const k = categoryOf(c)
  return k === 'rapid' || k === 'classical'
}

/** "3+2" = 3 minutes plus 2 seconds per move. */
export const formatControl = (c: TimeControl): string => `${c.baseMs / 60_000}+${c.incrementMs / 1000}`

export const createClock = (control: TimeControl): ClockState => ({
  control,
  remaining: { w: control.baseMs, b: control.baseMs },
  since: null,
  paused: null,
})

/** Time `color` has left at `now`, given that `turn` is the side to move. Never negative. */
export function timeLeft(clock: ClockState, turn: Color, color: Color, now: number): number {
  const base = clock.remaining[color]
  if (clock.since !== null && color === turn) return Math.max(0, base - Math.max(0, now - clock.since))
  return base
}

/** Charges the running side and stops the clock. */
export function stopClock(clock: ClockState, turn: Color, now: number): ClockState {
  if (clock.since === null) return clock
  return { ...clock, remaining: { ...clock.remaining, [turn]: timeLeft(clock, turn, turn, now) }, since: null }
}

/**
 * Clock after `mover` plays a move. White's very first move is free: no time is charged and
 * no increment is added, and Black's clock starts. From then on the mover is charged and
 * receives the increment, and the opponent's clock starts (unless the game just ended).
 */
export function clockAfterMove(clock: ClockState, mover: Color, firstMoveOfGame: boolean, gameOver: boolean, now: number): ClockState {
  const remaining = { ...clock.remaining }
  if (!firstMoveOfGame) {
    const used = clock.since === null ? 0 : Math.max(0, now - clock.since)
    remaining[mover] = Math.max(0, remaining[mover] - used) + clock.control.incrementMs
  }
  return { ...clock, remaining, since: gameOver ? null : now }
}

export const isTicking = (clock: ClockState | null): boolean => !!clock && clock.since !== null && clock.paused === null

/** "4:07", "1:02:30" or, under 10 s, "9.4". Rounds up so 0:00 only shows when time is out. */
export function formatClock(ms: number): string {
  const t = Math.max(0, ms)
  if (t < 10_000) return (Math.ceil(t / 100) / 10).toFixed(1)
  const total = Math.ceil(t / 1000)
  const h = Math.floor(total / 3600)
  const m = Math.floor((total % 3600) / 60)
  const s = total % 60
  const pad = (n: number) => String(n).padStart(2, '0')
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`
}
