import type { ReactNode } from 'react'

const paths: Record<string, ReactNode> = {
  first: (
    <>
      <path d="M6 5v14" />
      <path d="M18 6l-8 6 8 6z" />
    </>
  ),
  prev: <path d="M15 6l-6 6 6 6" />,
  next: <path d="M9 6l6 6-6 6" />,
  last: (
    <>
      <path d="M18 5v14" />
      <path d="M6 6l8 6-8 6z" />
    </>
  ),
  undo: (
    <>
      <path d="M9 14L4 9l5-5" />
      <path d="M4 9h10a6 6 0 0 1 0 12h-3" />
    </>
  ),
  redo: (
    <>
      <path d="M15 14l5-5-5-5" />
      <path d="M20 9H10a6 6 0 0 0 0 12h3" />
    </>
  ),
  flip: (
    <>
      <path d="M7 4v15m0 0l-3-3m3 3l3-3" />
      <path d="M17 20V5m0 0l-3 3m3-3l3 3" />
    </>
  ),
  restart: (
    <>
      <path d="M4 12a8 8 0 1 0 2.6-5.9" />
      <path d="M4 4v5h5" />
    </>
  ),
  plus: <path d="M12 5v14M5 12h14" />,
  flag: (
    <>
      <path d="M6 21V4" />
      <path d="M6 5h12l-2.5 4L18 13H6" />
    </>
  ),
  draw: <path d="M5 9h14M5 15h14" />,
  trash: (
    <>
      <path d="M4 7h16" />
      <path d="M10 11v6M14 11v6" />
      <path d="M6 7l1 13h10l1-13" />
      <path d="M9 7V4h6v3" />
    </>
  ),
  board: (
    <>
      <rect x="4" y="4" width="16" height="16" rx="2" />
      <path d="M12 4v16M4 12h16" />
    </>
  ),
  list: <path d="M5 6h14M5 12h14M5 18h9" />,
  help: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M9.6 9.3a2.5 2.5 0 1 1 3.6 2.2c-.8.4-1.2 1-1.2 1.8M12 17h.01" />
    </>
  ),
  copy: (
    <>
      <rect x="9" y="9" width="11" height="11" rx="2" />
      <path d="M5 15V6a2 2 0 0 1 2-2h8" />
    </>
  ),
  play: <path d="M8 5l11 7-11 7z" />,
  pause: <path d="M8 5v14M16 5v14" />,
  back: <path d="M15 6l-6 6 6 6" />,
  close: <path d="M6 6l12 12M18 6L6 18" />,
}

export type IconName = keyof typeof paths

export function Icon({ name }: { name: IconName }) {
  return (
    <svg className="icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      {paths[name]}
    </svg>
  )
}

export function Logo() {
  return (
    <svg width="28" height="28" viewBox="0 0 32 32" aria-hidden="true" focusable="false">
      <rect width="32" height="32" rx="7" fill="#161f27" stroke="#364859" />
      <g transform="translate(5 5)">
        <rect width="22" height="22" rx="3" fill="#e5e1d5" />
        <rect y="11" width="11" height="11" fill="#2f5d47" />
        <rect x="11" width="11" height="11" fill="#2f5d47" />
        <circle cx="16.5" cy="5.5" r="3.2" fill="#d5b16b" />
      </g>
    </svg>
  )
}
