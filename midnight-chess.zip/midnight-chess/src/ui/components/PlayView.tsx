import { useCallback, useEffect, useState } from 'react'
import type { Color, Square } from '../../engine/chessLib'
import { allowsManualPause } from '../../engine/clock'
import { colorName, describeControl, outcomeDetail, resultLabel } from '../../engine/messages'
import { DEFAULT_PLAYERS } from '../../engine/session'
import type { NavTarget } from '../../engine/session'
import type { PromotionPiece } from '../../engine/types'
import { ChessgroundBoard } from '../../board/ChessgroundBoard'
import { useStore } from '../StoreContext'
import { useFirstRunTip, useNavKeys, useReducedMotion, useSnapshot } from '../hooks'
import { Icon } from '../icons'
import { ConfirmDialog, NewGameDialog, PromotionDialog, ResignDialog } from './Dialogs'
import { MoveList } from './MoveList'
import { NavControls } from './NavControls'
import { PlayerStrip } from './PlayerStrip'

type Dialog = 'new' | 'restart' | 'resign' | 'draw' | null

const PAUSE_TEXT = {
  manual: 'Pausa manual. Os dois relógios estão parados.',
  auto: 'Pausada porque o app saiu de foco. Os dois relógios estão parados.',
  restore: 'Partida recuperada. O tempo desde o último lance salvo não foi cobrado.',
} as const

export function PlayView({ helpOpen }: { helpOpen: boolean }) {
  const store = useStore()
  const snap = useSnapshot()
  const reduced = useReducedMotion()
  const [dialog, setDialog] = useState<Dialog>(null)
  const [promotion, setPromotion] = useState<{ from: Square; to: Square } | null>(null)
  const [resync, setResync] = useState(0)
  const [tipVisible, dismissTip] = useFirstRunTip()

  const { game, view, live, outcome } = snap
  const clock = game.clock
  const timed = clock !== null
  const navigate = useCallback((t: NavTarget) => store.navigate(t), [store])
  useNavKeys(navigate, dialog === null && promotion === null && !helpOpen)

  // a new game starts with the board in view (on a phone the buttons that start it are below the fold)
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [game.id])

  // time ran out (or the game was paused) while the promotion dialog was open: drop the half-made move
  useEffect(() => {
    if (promotion && !snap.canPlay) {
      setPromotion(null)
      setResync((n) => n + 1)
    }
  }, [promotion, snap.canPlay])

  const onMove = (from: Square, to: Square) => {
    const r = store.move(from, to)
    if (r === 'promotion-required') {
      setPromotion({ from, to })
      return 'pending' as const
    }
    return r === 'ok' || r === 'duplicate' ? ('accepted' as const) : ('rejected' as const)
  }
  const choosePromotion = (p: PromotionPiece) => {
    if (promotion) store.move(promotion.from, promotion.to, p)
    setPromotion(null)
  }
  const cancelPromotion = () => {
    setPromotion(null)
    setResync((n) => n + 1)
  }

  const top: Color = game.orientation === 'w' ? 'b' : 'w'
  const strip = (c: Color) => (
    <PlayerStrip
      color={c}
      name={game.players[c]}
      toMove={live.turn === c}
      inCheck={live.inCheck}
      outcome={outcome}
      clock={clock}
      turn={live.turn}
      now={store.nowMs}
    />
  )
  const viewing = game.viewIndex !== game.moves.length
  const lastSan = game.viewIndex > 0 ? game.moves[game.viewIndex - 1].san : null
  const boardLabel = `Tabuleiro de xadrez. ${outcome ? resultLabel(outcome) : `Vez das ${colorName(live.turn)}`}. ${lastSan ? `Lance exibido: ${lastSan}.` : 'Posição inicial.'}`

  const askRestart = () => (snap.hasProgress ? setDialog('restart') : store.restart())
  const claimLabel = live.claim.threefold ? 'Reivindicar empate: repetição tripla' : 'Reivindicar empate: regra dos 50 lances'
  const leaveHint = 'Partida com relógio em andamento: use Desistir ou Empate para encerrar.'
  const manualPause = clock ? allowsManualPause(clock.control) : false

  return (
    <div className="stage" data-testid="play">
      <div className="board-col">
        {strip(top)}
        <div className="board-slot">
          <ChessgroundBoard
            fen={view.fen}
            orientation={game.orientation}
            turn={view.turn}
            lastMove={view.lastMove}
            check={view.inCheck}
            dests={view.dests}
            interactive={snap.canPlay}
            reducedMotion={reduced}
            resyncToken={resync}
            label={boardLabel}
            onMove={onMove}
          />
          {clock?.paused && (
            <div className="pause-cover" role="group" aria-label="Partida pausada" data-testid="pause-cover">
              <h2>Partida pausada</h2>
              <p>{PAUSE_TEXT[clock.paused]}</p>
              <button type="button" className="btn btn-primary" onClick={() => store.resume()} autoFocus>
                Retomar
              </button>
            </div>
          )}
        </div>
        {strip(game.orientation)}
      </div>

      <aside className="panel" aria-label="Painel da partida">
        <div className={`status${outcome ? ' is-over' : ''}`} aria-live="polite">
          {outcome ? (
            <>
              <h1 className="status-title" data-testid="result">
                {resultLabel(outcome)}
              </h1>
              <p className="status-detail">{outcomeDetail(outcome, game.players)}</p>
              <div className="status-actions">
                <button type="button" className="btn btn-primary" onClick={() => setDialog('new')}>
                  <Icon name="plus" /> Nova partida
                </button>
              </div>
            </>
          ) : (
            <>
              <h1 className="status-title" data-testid="turn">
                {game.players[live.turn] === DEFAULT_PLAYERS[live.turn] ? `Vez das ${colorName(live.turn)}` : `Vez de ${game.players[live.turn]}`}
              </h1>
              <p className="status-detail">
                {live.inCheck ? 'Xeque! ' : ''}
                {clock?.paused
                  ? 'Partida pausada.'
                  : game.moves.length === 0
                    ? timed
                      ? `${describeControl(clock.control)}. O relógio começa depois do primeiro lance.`
                      : 'Aguardando o primeiro lance.'
                    : `Jogando com as ${colorName(live.turn)}.`}
              </p>
              {viewing && (
                <div className="status-actions">
                  <button type="button" className="btn" onClick={() => store.navigate('last')}>
                    Voltar ao último lance
                  </button>
                </div>
              )}
              {snap.canClaimDraw && (
                <div className="status-actions">
                  <button type="button" className="btn" onClick={() => store.claimDraw()}>
                    {claimLabel}
                  </button>
                </div>
              )}
            </>
          )}
        </div>

        <MoveList moves={game.moves} current={game.viewIndex} onSelect={(ply) => store.navigate(ply)} />
        <NavControls index={game.viewIndex} total={game.moves.length} onNav={navigate} />

        {tipVisible && (
          <div className="tip">
            <span>Toque numa peça e depois no destino, ou arraste. A partida é salva sozinha.</span>
            <button type="button" className="btn" onClick={dismissTip}>
              Entendi
            </button>
          </div>
        )}

        <div className="actions">
          {timed ? (
            <>
              {clock?.paused ? (
                <button type="button" className="btn btn-primary" disabled={snap.finished} onClick={() => store.resume()}>
                  <Icon name="play" /> Retomar
                </button>
              ) : (
                <button
                  type="button"
                  className="btn"
                  disabled={snap.finished || game.moves.length === 0 || !manualPause}
                  title={manualPause ? 'Pausar os dois relógios' : 'A pausa manual só existe nos modos Rápido e Clássico'}
                  onClick={() => store.pause()}
                >
                  <Icon name="pause" /> Pausar
                </button>
              )}
              <button type="button" className="btn" onClick={() => store.flip()}>
                <Icon name="flip" /> Girar
              </button>
              <button type="button" className="btn" disabled={!snap.hasProgress} onClick={() => setDialog('draw')}>
                <Icon name="draw" /> Empate
              </button>
            </>
          ) : (
            <>
              <button type="button" className="btn" disabled={!snap.canUndo} onClick={() => store.undo()}>
                <Icon name="undo" /> Desfazer
              </button>
              <button type="button" className="btn" disabled={!snap.canRedo} onClick={() => store.redo()}>
                <Icon name="redo" /> Refazer
              </button>
              <button type="button" className="btn" onClick={() => store.flip()}>
                <Icon name="flip" /> Girar
              </button>
            </>
          )}
        </div>
        <div className="actions-more">
          <button type="button" className="btn" disabled={!snap.canLeave} title={snap.canLeave ? undefined : leaveHint} onClick={askRestart}>
            <Icon name="restart" /> Reiniciar
          </button>
          <button type="button" className="btn" disabled={!snap.canLeave} title={snap.canLeave ? undefined : leaveHint} onClick={() => setDialog('new')}>
            <Icon name="plus" /> Nova partida
          </button>
          {!timed && (
            <button type="button" className="btn" disabled={!snap.hasProgress} onClick={() => setDialog('draw')}>
              <Icon name="draw" /> Empate
            </button>
          )}
          <button type="button" className="btn btn-danger" disabled={!snap.hasProgress} onClick={() => setDialog('resign')}>
            <Icon name="flag" /> Desistir
          </button>
        </div>
        {timed && !snap.finished && <p className="hint hint-panel">{leaveHint} Não há desfazer nem refazer.</p>}
      </aside>

      {dialog === 'new' && (
        <NewGameDialog
          open
          players={game.players}
          control={clock ? clock.control : null}
          hasProgress={snap.hasProgress}
          onStart={(p, control) => store.newGame(p, control)}
          onClose={() => setDialog(null)}
        />
      )}
      <ConfirmDialog
        open={dialog === 'restart'}
        title="Reiniciar a partida?"
        message="Os lances jogados até aqui serão descartados. Os jogadores continuam os mesmos."
        confirmLabel="Reiniciar"
        danger
        onConfirm={() => store.restart()}
        onClose={() => setDialog(null)}
      />
      <ConfirmDialog
        open={dialog === 'draw'}
        title="Empate por acordo?"
        message="A partida termina empatada. Confirme só se os dois jogadores concordam."
        confirmLabel="Encerrar em empate"
        onConfirm={() => store.agreeDraw()}
        onClose={() => setDialog(null)}
      />
      <ResignDialog open={dialog === 'resign'} players={game.players} onResign={(c) => store.resign(c)} onClose={() => setDialog(null)} />
      <PromotionDialog open={promotion !== null} color={live.turn} onChoose={choosePromotion} onCancel={cancelPromotion} />
    </div>
  )
}
