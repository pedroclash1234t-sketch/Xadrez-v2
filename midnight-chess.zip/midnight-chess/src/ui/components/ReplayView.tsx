import { useCallback, useState } from 'react'
import type { Color, Square } from '../../engine/chessLib'
import { describeControl, outcomeDetail, resultLabel } from '../../engine/messages'
import { analyzeMoves } from '../../engine/position'
import type { NavTarget } from '../../engine/session'
import type { GameRecord } from '../../persistence/schema'
import { ChessgroundBoard } from '../../board/ChessgroundBoard'
import { useNavKeys, useReducedMotion } from '../hooks'
import { Icon } from '../icons'
import { formatDate } from './HistoryView'
import { MoveList } from './MoveList'
import { NavControls } from './NavControls'
import { PlayerStrip } from './PlayerStrip'

interface Props {
  record: GameRecord
  dialogOpen: boolean
  onBack(): void
  onDelete(): void
  onCopyPgn(): void
}

const NO_DESTS: ReadonlyMap<Square, Square[]> = new Map()

export function ReplayView({ record, dialogOpen, onBack, onDelete, onCopyPgn }: Props) {
  const total = record.moves.length
  const [index, setIndex] = useState(total) // opens on the final position
  const [orientation, setOrientation] = useState<Color>('w')
  const reduced = useReducedMotion()
  const a = analyzeMoves(record.moves, index)

  const nav = useCallback(
    (t: NavTarget) =>
      setIndex((i) => {
        const raw = t === 'first' ? 0 : t === 'last' ? total : t === 'prev' ? i - 1 : t === 'next' ? i + 1 : t
        return Math.max(0, Math.min(total, raw))
      }),
    [total],
  )
  useNavKeys(nav, !dialogOpen)

  const outcome = {
    result: record.result,
    reason: record.reason,
    winner: record.result === '1-0' ? ('w' as const) : record.result === '0-1' ? ('b' as const) : undefined,
    flagged: record.flagged,
  }
  const players = { w: record.white, b: record.black }
  const strip = (c: Color) => <PlayerStrip color={c} name={players[c]} toMove={false} inCheck={false} outcome={outcome} />
  const top: Color = orientation === 'w' ? 'b' : 'w'
  const san = index > 0 ? record.moves[index - 1].san : null

  return (
    <div className="stage" data-testid="replay">
      <div className="board-col">
        {strip(top)}
        <ChessgroundBoard
          fen={a.fen}
          orientation={orientation}
          turn={a.turn}
          lastMove={a.lastMove}
          check={a.inCheck}
          dests={NO_DESTS}
          interactive={false}
          reducedMotion={reduced}
          resyncToken={0}
          label={`Tabuleiro da partida salva. ${san ? `Lance ${index}: ${san}.` : 'Posição inicial.'}`}
          onMove={() => 'rejected'}
        />
        {strip(orientation)}
      </div>
      <aside className="panel" aria-label="Partida salva">
        <div className="status is-over">
          <h1 className="status-title">{resultLabel(record)}</h1>
          <p className="status-detail">
            {outcomeDetail(outcome, players)} {formatDate(record.endedAt)}
            {record.timeControl ? ` · ${describeControl(record.timeControl)}` : ''}
            {record.source === 'imported' ? ' · Partida importada' : ''}
          </p>
          <p className="status-detail num" aria-live="polite">
            {index === 0 ? 'Posição inicial' : `Lance ${index} de ${total}`}
            {index === total ? ' (posição final)' : ''}
          </p>
        </div>
        <NavControls index={index} total={total} onNav={nav} />
        <MoveList moves={record.moves} current={index} onSelect={setIndex} />
        <div className="actions">
          <button type="button" className="btn" onClick={() => setOrientation((o) => (o === 'w' ? 'b' : 'w'))}>
            <Icon name="flip" /> Girar
          </button>
          <button type="button" className="btn" onClick={onCopyPgn}>
            <Icon name="copy" /> Copiar PGN
          </button>
          <button type="button" className="btn btn-danger" onClick={onDelete}>
            <Icon name="trash" /> Excluir
          </button>
        </div>
        <div className="actions-more single">
          <button type="button" className="btn" onClick={onBack}>
            <Icon name="back" /> Voltar à lista
          </button>
        </div>
      </aside>
    </div>
  )
}
