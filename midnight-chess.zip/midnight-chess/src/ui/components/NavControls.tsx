import type { NavTarget } from '../../engine/session'
import { Icon } from '../icons'

interface Props {
  index: number
  total: number
  onNav(t: NavTarget): void
}

export function NavControls({ index, total, onNav }: Props) {
  return (
    <div className="navbar" role="group" aria-label="Navegar pelos lances">
      <button type="button" className="icon-btn" aria-label="Primeiro lance" title="Início (Home)" disabled={index <= 0} onClick={() => onNav('first')}>
        <Icon name="first" />
      </button>
      <button type="button" className="icon-btn" aria-label="Lance anterior" title="Anterior (←)" disabled={index <= 0} onClick={() => onNav('prev')}>
        <Icon name="prev" />
      </button>
      <button type="button" className="icon-btn" aria-label="Próximo lance" title="Próximo (→)" disabled={index >= total} onClick={() => onNav('next')}>
        <Icon name="next" />
      </button>
      <button type="button" className="icon-btn" aria-label="Último lance" title="Fim (End)" disabled={index >= total} onClick={() => onNav('last')}>
        <Icon name="last" />
      </button>
    </div>
  )
}
