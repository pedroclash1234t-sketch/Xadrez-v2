import { useMemo, useState } from 'react'
import type { ChangeEvent } from 'react'
import { resultShort } from '../../engine/messages'
import { importPgn } from '../../engine/pgnImport'
import type { ImportedGame } from '../../engine/pgnImport'
import { Modal } from './Modal'

const MAX_FILE_BYTES = 1_000_000

interface Props {
  open: boolean
  onImport(game: ImportedGame): { ok: true } | { ok: false; error: string }
  onClose(): void
}

/** Paste or pick a .pgn file, see the verdict, and only then add the game to the history. */
export function ImportPgnDialog({ open, onImport, onClose }: Props) {
  const [text, setText] = useState('')
  const [fileError, setFileError] = useState<string | null>(null)
  const [storeError, setStoreError] = useState<string | null>(null)
  const parsed = useMemo(() => (text.trim() ? importPgn(text) : null), [text])

  const onFile = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    setFileError(null)
    setStoreError(null)
    if (!file) return
    if (file.size > MAX_FILE_BYTES) {
      setFileError('Arquivo grande demais (limite de 1 MB).')
      return
    }
    file
      .text()
      .then(setText)
      .catch(() => setFileError('Não foi possível ler o arquivo.'))
  }

  const add = () => {
    if (!parsed?.ok) return
    const r = onImport(parsed.game)
    if (r.ok) onClose()
    else setStoreError(r.error)
  }

  const error = fileError ?? storeError ?? (parsed && !parsed.ok ? parsed.error : null)
  return (
    <Modal open={open} title="Importar partida (PGN)" onClose={onClose}>
      <p>A partida é só adicionada ao histórico para você revisar: a partida em andamento não é alterada.</p>
      <label className="field">
        Texto do PGN
        <textarea
          className="pgn-text"
          rows={7}
          spellCheck={false}
          value={text}
          placeholder={'[White "Ana"]\n[Black "Beto"]\n[Result "1-0"]\n\n1. e4 e5 2. Nf3 ... 1-0'}
          onChange={(e) => {
            setText(e.target.value)
            setFileError(null)
            setStoreError(null)
          }}
        />
      </label>
      <label className="field">
        …ou um arquivo .pgn
        <input type="file" accept=".pgn,.txt,text/plain" onChange={onFile} />
      </label>
      {error && (
        <p className="field-error" role="alert" data-testid="pgn-error">
          {error}
        </p>
      )}
      {parsed?.ok && !error && (
        <p className="pgn-preview" data-testid="pgn-preview">
          {parsed.game.white} contra {parsed.game.black} · {resultShort(parsed.game)} · {Math.ceil(parsed.game.moves.length / 2)} lances
        </p>
      )}
      <div className="modal-actions">
        <button type="button" className="btn" onClick={onClose}>
          Cancelar
        </button>
        <button type="button" className="btn btn-primary" disabled={!parsed?.ok || !!storeError} onClick={add}>
          Adicionar ao histórico
        </button>
      </div>
    </Modal>
  )
}
