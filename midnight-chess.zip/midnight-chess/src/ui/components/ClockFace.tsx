import { useEffect, useState } from 'react'
import type { Color } from '../../engine/chessLib'
import { formatClock, timeLeft } from '../../engine/clock'
import type { ClockState } from '../../engine/clock'

interface Props {
  clock: ClockState
  /** Side to move in the live position. */
  turn: Color
  color: Color
  now(): number
}

/** One side's clock. Redraws 4x/s (10x/s in the last 10 s), and only while it is the one ticking. */
export function ClockFace({ clock, turn, color, now }: Props) {
  const ticking = clock.since !== null && clock.paused === null && turn === color
  const ms = timeLeft(clock, turn, color, now())
  const low = ms < 10_000 // tenths of a second are shown only then
  const [, bump] = useState(0)
  useEffect(() => {
    if (!ticking) return
    const id = setInterval(() => bump((n) => n + 1), low ? 100 : 250)
    return () => clearInterval(id)
  }, [ticking, low])

  const text = formatClock(ms)
  return (
    <span
      className="clock num"
      role="timer"
      data-testid={`clock-${color}`}
      data-ticking={ticking}
      data-low={low}
      data-paused={clock.paused !== null}
      aria-label={`Relógio das ${color === 'w' ? 'brancas' : 'pretas'}: ${text}`}
    >
      {text}
    </span>
  )
}
