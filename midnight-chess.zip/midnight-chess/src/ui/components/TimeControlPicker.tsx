import { useState } from 'react'
import { CATEGORY_LABEL, LIMITS, PRESETS, allowsManualPause, categoryOf, controlFrom, sameControl } from '../../engine/clock'
import type { TimeCategory, TimeControl } from '../../engine/clock'

type Mode = 'none' | TimeCategory | 'custom'
const CATEGORIES: TimeCategory[] = ['bullet', 'blitz', 'rapid', 'classical']

const presetLabel = (baseMin: number, incrementSec: number) => `${baseMin} min${incrementSec > 0 ? ` + ${incrementSec} s` : ''}`

function initialMode(value: TimeControl | null): Mode {
  if (!value) return 'none'
  const preset = PRESETS.find((p) => sameControl(controlFrom(p.baseMin, p.incrementSec), value))
  return preset ? preset.category : 'custom'
}

interface Props {
  value: TimeControl | null
  /** `undefined` means the custom values are not valid (the dialog keeps "start" disabled). */
  onChange(control: TimeControl | null | undefined): void
}

export function TimeControlPicker({ value, onChange }: Props) {
  const [mode, setMode] = useState<Mode>(() => initialMode(value))
  const [current, setCurrent] = useState<TimeControl | null | undefined>(value)
  const [minutes, setMinutes] = useState(value ? String(value.baseMs / 60_000) : '5')
  const [increment, setIncrement] = useState(value ? String(value.incrementMs / 1000) : '0')

  const choose = (c: TimeControl | null | undefined) => {
    setCurrent(c)
    onChange(c)
  }

  const pickMode = (m: Mode) => {
    setMode(m)
    if (m === 'none') return choose(null)
    if (m === 'custom') return choose(controlFrom(Number(minutes), Number(increment)) ?? undefined)
    const first = PRESETS.find((p) => p.category === m)
    choose(first ? controlFrom(first.baseMin, first.incrementSec) : null)
  }

  const custom = (mins: string, inc: string) => {
    setMinutes(mins)
    setIncrement(inc)
    choose(controlFrom(Number(mins), Number(inc)) ?? undefined)
  }

  const invalid = mode === 'custom' && current === undefined

  return (
    <fieldset className="picker">
      <legend>Relógio</legend>
      <div className="seg" role="group" aria-label="Modo de partida">
        {(['none', ...CATEGORIES, 'custom'] as Mode[]).map((m) => (
          <button key={m} type="button" className="seg-btn" aria-pressed={mode === m} onClick={() => pickMode(m)}>
            {m === 'none' ? 'Sem relógio' : m === 'custom' ? 'Outro' : CATEGORY_LABEL[m]}
          </button>
        ))}
      </div>

      {mode !== 'none' && mode !== 'custom' && (
        <div className="chips" role="group" aria-label="Tempo da partida">
          {PRESETS.filter((p) => p.category === mode).map((p) => {
            const c = controlFrom(p.baseMin, p.incrementSec)
            return (
              <button key={`${p.baseMin}+${p.incrementSec}`} type="button" className="chip-btn" aria-pressed={sameControl(c, current ?? null)} onClick={() => choose(c)}>
                {presetLabel(p.baseMin, p.incrementSec)}
              </button>
            )
          })}
        </div>
      )}

      {mode === 'custom' && (
        <div className="custom">
          <label className="field">
            Minutos (1 a {LIMITS.maxBaseMin})
            <input type="number" inputMode="numeric" min={LIMITS.minBaseMin} max={LIMITS.maxBaseMin} value={minutes} onChange={(e) => custom(e.target.value, increment)} />
          </label>
          <label className="field">
            Acréscimo por lance, em segundos (0 a {LIMITS.maxIncrementSec})
            <input type="number" inputMode="numeric" min={0} max={LIMITS.maxIncrementSec} value={increment} onChange={(e) => custom(minutes, e.target.value)} />
          </label>
          {invalid && <p className="field-error" role="alert">Use minutos e segundos inteiros dentro dos limites.</p>}
        </div>
      )}

      <p className="hint">
        {current
          ? `${CATEGORY_LABEL[categoryOf(current)]}. O relógio começa depois do primeiro lance das brancas. Sem desfazer, refazer nem reinício com a partida em andamento. Pausa manual: ${allowsManualPause(current) ? 'disponível' : 'não disponível neste modo'}.`
          : 'Sem relógio: desfazer e refazer ficam disponíveis.'}
      </p>
    </fieldset>
  )
}
