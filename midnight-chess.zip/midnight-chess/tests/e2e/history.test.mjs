import { after, before, describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { boardState, playClicks, settle, start, until } from './helpers.mjs'

let app
before(async () => {
  app = await start()
})
after(async () => {
  await app?.close()
})

describe('partidas anteriores', () => {
  it('mostra mensagem apropriada quando não há registros', async () => {
    const { page, context } = await app.open()
    await page.getByRole('button', { name: /Partidas/ }).click()
    await page.getByText('Nenhuma partida concluída ainda').waitFor()
    await page.getByRole('button', { name: 'Jogar agora' }).click()
    await page.locator('[data-testid=play]').waitFor()
    await context.close()
  })

  it('abre uma partida salva, percorre os lances, volta à posição final e exclui com confirmação', async () => {
    const { page, context, problems } = await app.open()
    await page.getByRole('button', { name: 'Nova partida' }).first().click()
    await page.getByLabel('Jogador das brancas').fill('Ana')
    await page.getByLabel('Jogador das pretas').fill('Beto')
    await page.getByRole('button', { name: 'Começar partida' }).click()
    await playClicks(page, 'f2f3 e7e5 g2g4 d8h4')
    await page.locator('[data-testid=result]').waitFor()
    assert.equal(await page.locator('[data-testid=result]').innerText(), 'Vitória das pretas')

    await page.getByRole('button', { name: /Partidas/ }).click()
    const row = page.locator('[data-testid=game-row]')
    assert.match(await row.innerText(), /Ana contra Beto/)
    assert.match(await row.innerText(), /0–1/)
    assert.match(await row.innerText(), /2 lances/)
    assert.match(await page.locator('.stats').innerText(), /Vitórias das pretas/)

    await row.click()
    await page.locator('[data-testid=replay]').waitFor()
    await settle(page)
    assert.equal((await boardState(page)).h4, 'q') // abre na posição final
    assert.match(await page.locator('[aria-live=polite]').last().innerText(), /Lance 4 de 4 \(posição final\)/)

    await page.getByRole('button', { name: 'Primeiro lance' }).click()
    await settle(page)
    let s = await boardState(page)
    assert.equal(s.d8, 'q')
    assert.equal(s.f2, 'P')
    await page.getByRole('button', { name: 'Próximo lance' }).click()
    await page.getByRole('button', { name: 'Próximo lance' }).click()
    await settle(page)
    s = await boardState(page)
    assert.equal(s.f3, 'P')
    assert.equal(s.e5, 'p')
    assert.equal(s.g4, undefined)
    await page.getByRole('button', { name: 'Último lance' }).click()
    await settle(page)
    assert.equal((await boardState(page)).h4, 'q')

    // clicar num lance salta direto para ele
    await page.getByRole('button', { name: 'Lance 1: f3' }).click()
    await settle(page)
    assert.equal((await boardState(page)).f3, 'P')
    assert.equal((await boardState(page)).e5, undefined)

    // excluir pede confirmação
    await page.getByRole('button', { name: 'Excluir' }).click()
    await page.getByRole('heading', { name: 'Excluir esta partida?' }).waitFor()
    await page.getByRole('button', { name: 'Cancelar' }).click()
    assert.equal(await page.locator('[data-testid=replay]').count(), 1)
    await page.getByRole('button', { name: 'Excluir' }).click()
    await page.getByRole('dialog').getByRole('button', { name: 'Excluir' }).click()
    await page.getByText('Nenhuma partida concluída ainda').waitFor()
    await page.reload()
    await page.getByRole('button', { name: /Partidas/ }).click()
    await page.getByText('Nenhuma partida concluída ainda').waitFor()
    assert.deepEqual(problems, [])
    await context.close()
  })

  it('o PGN salvo é copiado para a área de transferência', async () => {
    const { page, context } = await app.open()
    await context.grantPermissions(['clipboard-read', 'clipboard-write'])
    await playClicks(page, 'f2f3 e7e5 g2g4 d8h4')
    await page.getByRole('button', { name: /Partidas/ }).click()
    await page.locator('[data-testid=game-row]').click()
    await page.getByRole('button', { name: 'Copiar PGN' }).click()
    await until(async () => (await page.evaluate(() => navigator.clipboard.readText())).includes('Qh4#'), 'PGN na área de transferência')
    const pgn = await page.evaluate(() => navigator.clipboard.readText())
    assert.match(pgn, /\[Result "0-1"\]/)
    await context.close()
  })
})
