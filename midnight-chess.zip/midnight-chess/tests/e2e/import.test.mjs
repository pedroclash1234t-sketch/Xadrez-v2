import { after, before, describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { writeFileSync, mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { boardState, moveTexts, playClicks, settle, start } from './helpers.mjs'

let app
before(async () => {
  app = await start()
})
after(async () => {
  await app?.close()
})

const VALID = `[White "Ana"]
[Black "Beto"]
[Date "2024.03.09"]
[Result "1-0"]

1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6 1-0`

async function openImport(page) {
  await page.getByRole('button', { name: /Partidas/ }).click()
  await page.getByRole('button', { name: 'Importar PGN' }).click()
  await page.getByRole('dialog').waitFor()
}

describe('importar PGN', () => {
  it('texto inválido mostra o motivo e não deixa adicionar; o histórico e a partida salva ficam intactos', async () => {
    const { page, context, problems } = await app.open()
    await playClicks(page, 'e2e4 e7e5')
    const savedBefore = await page.evaluate(() => localStorage.getItem('midnight-chess:current'))
    await openImport(page)
    const add = page.getByRole('button', { name: 'Adicionar ao histórico' })
    assert.equal(await add.isDisabled(), true)
    const box = page.getByLabel('Texto do PGN')
    for (const [text, expected] of [
      ['isto não é xadrez', /não é um PGN válido/],
      ['1. e4 e5 2. Ke4 1-0', /Lance ilegal ou ambíguo no PGN: Ke4/],
      ['[Result "1-0"]\n\n1. e4 e5 0-1', /cabeçalho \(1-0\).*\(0-1\)/],
      ['1. e4 e5 2. Nf3', /não informa o resultado/],
    ]) {
      await box.fill(text)
      assert.match(await page.getByTestId('pgn-error').innerText(), expected)
      assert.equal(await add.isDisabled(), true)
    }
    await page.getByRole('button', { name: 'Cancelar' }).click()
    await page.getByText('Nenhuma partida concluída ainda').waitFor()
    assert.equal(await page.evaluate(() => localStorage.getItem('midnight-chess:current')), savedBefore)
    assert.equal(await page.evaluate(() => localStorage.getItem('midnight-chess:history')), null)
    await page.getByRole('button', { name: 'Jogar', exact: true }).click()
    await settle(page)
    assert.deepEqual(await moveTexts(page), ['e4', 'e5']) // a partida em andamento continua jogável e igual
    assert.deepEqual(problems, [])
    await context.close()
  })

  it('PGN válido: prévia, adiciona como "Importada", abre no replay e não conta nas estatísticas', async () => {
    const { page, context } = await app.open()
    await openImport(page)
    await page.getByLabel('Texto do PGN').fill(VALID)
    assert.match(await page.getByTestId('pgn-preview').innerText(), /Ana contra Beto · 1–0 · 4 lances/)
    await page.getByRole('button', { name: 'Adicionar ao histórico' }).click()
    await page.getByRole('dialog').waitFor({ state: 'detached' })
    const row = page.locator('[data-testid=game-row]')
    assert.match(await row.innerText(), /Ana contra Beto/)
    assert.match(await row.innerText(), /Importada/)
    assert.equal(await page.locator('.stats').count(), 0) // só havia partida importada: sem estatísticas de jogo

    await row.click()
    await page.locator('[data-testid=replay]').waitFor()
    await settle(page)
    assert.equal((await boardState(page)).f6, 'n')
    assert.match(await page.locator('.status-detail').first().innerText(), /Partida importada/)
    await page.getByRole('button', { name: 'Primeiro lance' }).click()
    await settle(page)
    assert.equal((await boardState(page)).e2, 'P')

    // sobrevive a recarregar
    await page.reload()
    await page.getByRole('button', { name: /Partidas/ }).click()
    assert.equal(await page.locator('[data-testid=game-row]').count(), 1)
    await context.close()
  })

  it('a mesma partida não entra duas vezes', async () => {
    const { page, context } = await app.open()
    await openImport(page)
    await page.getByLabel('Texto do PGN').fill(VALID)
    await page.getByRole('button', { name: 'Adicionar ao histórico' }).click()
    await page.getByRole('dialog').waitFor({ state: 'detached' })
    await openImport(page)
    await page.getByLabel('Texto do PGN').fill(VALID)
    await page.getByRole('button', { name: 'Adicionar ao histórico' }).click()
    assert.match(await page.getByTestId('pgn-error').innerText(), /já foi importada/)
    await page.getByRole('button', { name: 'Cancelar' }).click()
    assert.equal(await page.locator('[data-testid=game-row]').count(), 1)
    await context.close()
  })

  it('importa a partir de um arquivo .pgn', async () => {
    const { page, context } = await app.open()
    const dir = mkdtempSync(join(tmpdir(), 'pgn-'))
    const file = join(dir, 'partida.pgn')
    writeFileSync(file, VALID.replace('Ana', 'Carla'))
    await openImport(page)
    await page.locator('input[type=file]').setInputFiles(file)
    await page.getByTestId('pgn-preview').waitFor()
    assert.match(await page.getByTestId('pgn-preview').innerText(), /Carla contra Beto/)
    await page.getByRole('button', { name: 'Adicionar ao histórico' }).click()
    await page.getByRole('dialog').waitFor({ state: 'detached' })
    assert.match(await page.locator('[data-testid=game-row]').innerText(), /Carla contra Beto/)
    await context.close()
  })

  it('o PGN exportado por uma partida jogada volta a ser importável (ida e volta)', async () => {
    const { page, context } = await app.open()
    await context.grantPermissions(['clipboard-read', 'clipboard-write'])
    await playClicks(page, 'f2f3 e7e5 g2g4 d8h4')
    await page.getByRole('button', { name: /Partidas/ }).click()
    await page.locator('[data-testid=game-row]').click()
    await page.getByRole('button', { name: 'Copiar PGN' }).click()
    const pgn = await page.evaluate(() => navigator.clipboard.readText())
    await page.getByRole('button', { name: 'Voltar à lista' }).click()
    await openImport(page)
    await page.getByLabel('Texto do PGN').fill(pgn)
    await page.getByTestId('pgn-preview').waitFor()
    assert.match(await page.getByTestId('pgn-preview').innerText(), /0–1 · 2 lances/)
    await page.getByRole('button', { name: 'Adicionar ao histórico' }).click()
    await page.getByRole('dialog').waitFor({ state: 'detached' })
    assert.equal(await page.locator('[data-testid=game-row]').count(), 2)
    await context.close()
  })
})
