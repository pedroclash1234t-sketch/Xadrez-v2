import { after, before, describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { boardState, click, clockText, moveTexts, newTimedGame, playClicks, settle, start, until } from './helpers.mjs'

const F = { frozen: true }
let app
before(async () => {
  app = await start()
})
after(async () => {
  await app?.close()
})

describe('relógio: contagem e modos', () => {
  it('Blitz 3+2: ambos começam em 3:00; só depois do 1º lance das brancas o das pretas corre', async () => {
    const { page, context, problems } = await app.openFrozen()
    await newTimedGame(page, 'Blitz', '3 min + 2 s')
    assert.equal(await clockText(page, 'w'), '3:00')
    assert.equal(await clockText(page, 'b'), '3:00')
    assert.match(await page.locator('.status-detail').first().innerText(), /Blitz 3\+2\. O relógio começa depois do primeiro lance/)
    await page.clock.runFor(20_000) // antes do 1º lance nada corre
    assert.equal(await clockText(page, 'w'), '3:00')

    await playClicks(page, 'e2e4', F)
    assert.equal(await page.locator('[data-testid=clock-b]').getAttribute('data-ticking'), 'true')
    assert.equal(await page.locator('[data-testid=clock-w]').getAttribute('data-ticking'), 'false')
    assert.equal(await clockText(page, 'w'), '3:00') // o 1º lance foi grátis, sem acréscimo
    await page.clock.runFor(7_000)
    assert.equal(await clockText(page, 'b'), '2:53')

    await playClicks(page, 'e7e5', F) // pretas: 3:00 - 7 s + 2 s
    assert.equal(await clockText(page, 'b'), '2:55')
    assert.equal(await page.locator('[data-testid=clock-w]').getAttribute('data-ticking'), 'true')
    await page.clock.runFor(10_000)
    assert.equal(await clockText(page, 'w'), '2:50')
    assert.deepEqual(problems, [])
    await context.close()
  })

  it('tempo esgotado: a partida termina, o tabuleiro trava e o histórico registra o modo', async () => {
    const { page, context } = await app.openFrozen()
    await newTimedGame(page, 'Blitz', '3 min')
    await playClicks(page, 'e2e4', F)
    await page.clock.fastForward(181_000)
    await page.locator('[data-testid=result]').waitFor()
    assert.equal(await page.locator('[data-testid=result]').innerText(), 'Vitória das brancas')
    assert.match(await page.locator('.status-detail').first().innerText(), /Pretas ficou sem tempo/)
    assert.equal(await clockText(page, 'b'), '0.0')
    assert.match(await page.locator('.player[data-color=b]').innerText(), /Sem tempo/)
    await click(page, 'e7', F)
    await click(page, 'e5', F)
    assert.deepEqual(await moveTexts(page), ['e4'])
    await page.getByRole('button', { name: /Partidas/ }).click()
    const row = await page.locator('[data-testid=game-row]').innerText()
    assert.match(row, /Tempo esgotado/)
    assert.match(row, /Blitz 3\+0/)
    await context.close()
  })

  it('a bandeira cai mesmo com o usuário na aba Partidas', async () => {
    const { page, context } = await app.openFrozen()
    await newTimedGame(page, 'Bullet', '1 min')
    await playClicks(page, 'd2d4', F)
    await page.getByRole('button', { name: /Partidas/ }).click()
    await page.getByText('Nenhuma partida concluída ainda').waitFor()
    await page.clock.fastForward(61_000)
    await page.locator('[data-testid=game-row]').waitFor()
    assert.match(await page.locator('[data-testid=game-row]').innerText(), /Tempo esgotado/)
    await context.close()
  })

  it('promoção em andamento quando o tempo acaba: o diálogo fecha e a partida termina', async () => {
    const { page, context } = await app.openFrozen()
    await newTimedGame(page, 'Bullet', '1 min')
    await playClicks(page, 'a2a4 b7b5 a4b5 a7a6 b5a6 g8f6 a6a7 h7h6', F)
    await click(page, 'a7', F)
    await click(page, 'b8', F)
    await page.locator('.promo-grid').waitFor()
    await page.clock.fastForward(61_000)
    await page.locator('dialog[open]').waitFor({ state: 'detached' })
    await page.locator('[data-testid=result]').waitFor()
    assert.equal(await page.locator('[data-testid=result]').innerText(), 'Vitória das pretas')
    assert.equal((await moveTexts(page)).length, 8) // o lance de promoção não foi aplicado
    await context.close()
  })

  it('em tempo real (sem relógio falso) o relógio corre e mostra décimos no fim', async () => {
    const { page, context } = await app.open()
    await newTimedGame(page, 'Bullet', '1 min')
    await playClicks(page, 'e2e4')
    await until(async () => ['0:59', '0:58'].includes(await clockText(page, 'b')), 'relógio das pretas andou', 4000)
    assert.equal(await page.locator('[data-testid=clock-b]').getAttribute('data-ticking'), 'true')
    await context.close()
  })
})

describe('relógio: pausa', () => {
  it('Blitz não tem pausa manual; o botão explica por quê', async () => {
    const { page, context } = await app.openFrozen()
    await newTimedGame(page, 'Blitz', '5 min')
    await playClicks(page, 'e2e4', F)
    const btn = page.getByRole('button', { name: 'Pausar' })
    assert.equal(await btn.isDisabled(), true)
    assert.match(await btn.getAttribute('title'), /Rápido e Clássico/)
    await context.close()
  })

  it('Rápido: pausar cobre o tabuleiro, para os dois relógios e trava os lances; retomar não cobra o tempo parado', async () => {
    const { page, context } = await app.openFrozen()
    await newTimedGame(page, 'Rápido', '10 min')
    await playClicks(page, 'e2e4', F)
    await page.clock.runFor(4_000)
    await page.getByRole('button', { name: 'Pausar' }).click()
    await page.locator('[data-testid=pause-cover]').waitFor()
    assert.match(await page.locator('[data-testid=pause-cover]').innerText(), /Pausa manual/)
    const frozenB = await clockText(page, 'b')
    assert.equal(frozenB, '9:56')
    await page.clock.runFor(300_000) // cinco minutos pausado
    assert.equal(await clockText(page, 'b'), frozenB)
    assert.equal(await clockText(page, 'w'), '10:00')
    // a cobertura intercepta o toque: nenhum lance entra
    await click(page, 'e7', F)
    await click(page, 'e5', F)
    assert.deepEqual(await moveTexts(page), ['e4'])
    await page.locator('[data-testid=pause-cover]').getByRole('button', { name: 'Retomar' }).click()
    await page.locator('[data-testid=pause-cover]').waitFor({ state: 'detached' })
    await page.clock.runFor(6_000)
    assert.equal(await clockText(page, 'b'), '9:50')
    await playClicks(page, 'e7e5', F)
    await context.close()
  })

  it('o app sair de foco pausa qualquer modo e pede para retomar', async () => {
    const { page, context } = await app.openFrozen()
    await newTimedGame(page, 'Blitz', '3 min')
    await playClicks(page, 'e2e4', F)
    await page.clock.runFor(5_000)
    await page.evaluate(() => {
      Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'hidden' })
      document.dispatchEvent(new Event('visibilitychange'))
    })
    await page.locator('[data-testid=pause-cover]').waitFor()
    assert.match(await page.locator('[data-testid=pause-cover]').innerText(), /saiu de foco/)
    await page.clock.runFor(120_000)
    await page.evaluate(() => {
      Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'visible' })
      document.dispatchEvent(new Event('visibilitychange'))
    })
    assert.equal(await page.locator('[data-testid=pause-cover]').count(), 1) // volta pausada: precisa tocar
    assert.equal(await clockText(page, 'b'), '2:55') // só os 5 s antes de sair
    await page.getByRole('button', { name: 'Retomar' }).first().click()
    await playClicks(page, 'e7e5', F)
    await context.close()
  })

  it('recarregar a página: o app pausa ao sair, cobra o tempo exato até ali e volta pausado', async () => {
    const { page, context } = await app.openFrozen()
    await newTimedGame(page, 'Blitz', '3 min')
    await playClicks(page, 'e2e4', F)
    await page.clock.runFor(30_000)
    await page.reload() // dispara pagehide: pausa automática com o tempo exato
    await page.waitForSelector('cg-board piece')
    await page.locator('[data-testid=pause-cover]').waitFor()
    assert.match(await page.locator('[data-testid=pause-cover]').innerText(), /saiu de foco/)
    assert.deepEqual(await moveTexts(page), ['e4'])
    assert.equal(await clockText(page, 'b'), '2:30') // os 30 s em que o relógio rodou foram cobrados
    await page.clock.runFor(60_000)
    assert.equal(await clockText(page, 'b'), '2:30') // parado enquanto pausado
    await page.getByRole('button', { name: 'Retomar' }).first().click()
    await playClicks(page, 'e7e5', F)
    assert.equal((await moveTexts(page)).length, 2)
    await context.close()
  })

  it('app encerrado sem aviso (sem pagehide): volta pausado e o tempo desde o último lance não é cobrado', async () => {
    const { page, context } = await app.openFrozen()
    await newTimedGame(page, 'Blitz', '3 min')
    await playClicks(page, 'e2e4', F)
    // estado em disco exatamente como estava com o relógio das pretas correndo
    const saved = await page.evaluate(() => localStorage.getItem('midnight-chess:current'))
    assert.equal(JSON.parse(saved).session.clock.paused, null)
    assert.notEqual(JSON.parse(saved).session.clock.since, null)
    await page.close()
    await page.clock.runFor(3_600_000).catch(() => {}) // uma hora "com o app fechado"
    const reopened = await context.newPage()
    await reopened.addInitScript((value) => localStorage.setItem('midnight-chess:current', value), saved)
    await reopened.goto(app.base)
    await reopened.waitForSelector('cg-board piece')
    await reopened.locator('[data-testid=pause-cover]').waitFor()
    assert.match(await reopened.locator('[data-testid=pause-cover]').innerText(), /recuperada/)
    assert.equal(await clockText(reopened, 'b'), '3:00')
    assert.deepEqual(await moveTexts(reopened), ['e4'])
    await context.close()
  })
})

describe('relógio: regras de desfazer e recomeçar', () => {
  it('com relógio e partida em andamento: sem desfazer/refazer, sem reiniciar nem nova partida; desistir libera', async () => {
    const { page, context } = await app.openFrozen()
    await newTimedGame(page, 'Blitz', '3 min')
    // antes do 1º lance ainda dá para recomeçar
    assert.equal(await page.getByRole('button', { name: 'Reiniciar' }).isDisabled(), false)
    await playClicks(page, 'e2e4 e7e5', F)
    assert.equal(await page.getByRole('button', { name: 'Desfazer' }).count(), 0) // nem aparece no modo cronometrado
    assert.equal(await page.getByRole('button', { name: 'Refazer' }).count(), 0)
    const restart = page.getByRole('button', { name: 'Reiniciar' })
    const fresh = page.getByRole('button', { name: 'Nova partida' }).first()
    assert.equal(await restart.isDisabled(), true)
    assert.equal(await fresh.isDisabled(), true)
    assert.match(await restart.getAttribute('title'), /Desistir ou Empate/)
    assert.match(await page.locator('.hint-panel').innerText(), /Não há desfazer nem refazer/)
    assert.deepEqual(await moveTexts(page), ['e4', 'e5'])

    await page.getByRole('button', { name: 'Desistir' }).click()
    await page.getByRole('button', { name: /Brancas \(brancas\)/ }).click()
    await page.locator('[data-testid=result]').waitFor()
    assert.equal(await page.getByRole('button', { name: 'Reiniciar' }).isDisabled(), false)
    assert.equal(await page.getByRole('button', { name: 'Nova partida' }).first().isDisabled(), false)
    await context.close()
  })

  it('sem relógio nada mudou: desfazer, refazer e reiniciar com confirmação', async () => {
    const { page, context } = await app.open()
    await playClicks(page, 'e2e4 e7e5', F)
    await page.getByRole('button', { name: 'Desfazer' }).click()
    await until(async () => (await moveTexts(page)).length === 1, 'desfeito')
    assert.equal(await page.getByRole('button', { name: 'Reiniciar' }).isDisabled(), false)
    assert.equal(await page.getByRole('button', { name: 'Pausar' }).count(), 0)
    await settle(page)
    assert.equal((await boardState(page)).e7, 'p')
    await context.close()
  })

  it('modo personalizado: valida os limites antes de permitir começar', async () => {
    const { page, context } = await app.openFrozen()
    await page.getByRole('button', { name: 'Nova partida' }).first().click()
    await page.getByRole('button', { name: 'Outro', exact: true }).click()
    const start = page.getByRole('button', { name: 'Começar partida' })
    await page.getByLabel(/^Minutos/).fill('0')
    assert.equal(await start.isDisabled(), true)
    await page.getByLabel(/^Minutos/).fill('4')
    await page.getByLabel(/^Acréscimo/).fill('2')
    assert.equal(await start.isDisabled(), false)
    await start.click()
    await page.locator('dialog[open]').waitFor({ state: 'detached' })
    assert.equal(await clockText(page, 'w'), '4:00')
    assert.match(await page.locator('.status-detail').first().innerText(), /Blitz 4\+2/)
    await context.close()
  })
})

describe('relógio: telas pequenas', () => {
  it('360×640 com relógio: faixas dos jogadores cabem, relógios visíveis e sem rolagem horizontal', async () => {
    const { page, context } = await app.openFrozen({ viewport: { width: 360, height: 640 }, isMobile: true, hasTouch: true })
    await newTimedGame(page, 'Rápido', '15 min + 10 s')
    await playClicks(page, 'e2e4', { touch: true, frozen: true })
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth), 0)
    for (const color of ['w', 'b']) {
      const box = await page.locator(`[data-testid=clock-${color}]`).boundingBox()
      assert.ok(box.x >= 0 && box.x + box.width <= 360, `relógio ${color} dentro da tela`)
      const strip = await page.locator(`.player[data-color=${color}]`).boundingBox()
      assert.ok(strip.x >= 0 && strip.x + strip.width <= 360.5)
    }
    const name = await page.locator('.player[data-color=w] .player-name').boundingBox()
    assert.ok(name.width > 40, `nome ainda legível (${name.width}px)`)
    // pausa por toque
    await page.getByRole('button', { name: 'Pausar' }).tap()
    await page.locator('[data-testid=pause-cover]').waitFor()
    const cover = await page.locator('[data-testid=pause-cover]').boundingBox()
    assert.ok(cover.width > 200 && cover.height > 200)
    await page.getByRole('button', { name: 'Retomar' }).first().tap()
    await context.close()
  })
})
