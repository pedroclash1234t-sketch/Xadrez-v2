import { chromium } from 'playwright'
import { existsSync } from 'node:fs'
import { runBuild } from '../../scripts/build.mjs'
import { serve } from '../../scripts/preview.mjs'

export async function start() {
  if (!existsSync(new URL('../../dist/app.js', import.meta.url))) await runBuild()
  const server = await serve(0)
  const base = `http://localhost:${server.address().port}/`
  const browser = await chromium.launch()
  return {
    base,
    browser,
    async close() {
      await browser.close()
      server.close()
    },
    /**
     * Same as open(), but with Playwright's fake clock installed before the page loads and then
     * frozen: time only moves when the test calls page.clock.runFor / fastForward.
     */
    async openFrozen(options = {}) {
      const context = await browser.newContext({ viewport: { width: 1280, height: 800 }, reducedMotion: 'reduce', ...options })
      const page = await context.newPage()
      const problems = []
      page.on('console', (m) => {
        if (m.type() === 'error' || m.type() === 'warning') problems.push(`${m.type()}: ${m.text()}`)
      })
      page.on('pageerror', (e) => problems.push(`pageerror: ${e.message}`))
      await page.clock.install({ time: new Date('2026-10-18T12:00:00Z') })
      await page.goto(base)
      await page.waitForSelector('cg-board piece')
      await page.clock.pauseAt(new Date('2026-10-18T12:00:05Z'))
      return { context, page, problems }
    },
    /** Fresh browser profile (empty localStorage) with console error capture. */
    async open(options = {}) {
      const context = await browser.newContext({ viewport: { width: 1280, height: 800 }, ...options })
      const page = await context.newPage()
      const problems = []
      page.on('console', (m) => {
        if (m.type() === 'error' || m.type() === 'warning') problems.push(`${m.type()}: ${m.text()}`)
      })
      page.on('pageerror', (e) => problems.push(`pageerror: ${e.message}`))
      await page.goto(base)
      await page.waitForSelector('cg-board piece')
      return { context, page, problems }
    },
  }
}

export async function until(fn, msg, timeout = 5000) {
  const t0 = Date.now()
  let last
  while (Date.now() - t0 < timeout) {
    try {
      last = await fn()
      if (last) return last
    } catch {
      /* retry */
    }
    await new Promise((r) => setTimeout(r, 50))
  }
  throw new Error(`Tempo esgotado: ${msg} (último valor: ${JSON.stringify(last)})`)
}

const LETTER = { pawn: 'p', knight: 'n', bishop: 'b', rook: 'r', queen: 'q', king: 'k' }

/** What is actually drawn on the board right now: { e4: 'P', e5: 'p', ... }. */
export async function boardState(page) {
  return page.evaluate((LETTER) => {
    const board = document.querySelector('cg-board')
    const size = board.getBoundingClientRect().width / 8
    const black = document.querySelector('.board-frame .cg-wrap').classList.contains('orientation-black')
    const out = {}
    for (const p of board.querySelectorAll('piece')) {
      if (p.classList.contains('ghost')) continue
      const m = /translate\(\s*([-\d.]+)px,\s*([-\d.]+)px/.exec(p.style.transform)
      if (!m) continue
      const f = Math.round(parseFloat(m[1]) / size)
      const r = Math.round(parseFloat(m[2]) / size)
      const file = 'abcdefgh'[black ? 7 - f : f]
      const rank = black ? r + 1 : 8 - r
      const role = [...p.classList].find((c) => LETTER[c])
      const color = p.classList.contains('white') ? 'w' : 'b'
      out[file + rank] = color === 'w' ? LETTER[role].toUpperCase() : LETTER[role]
    }
    return out
  }, LETTER)
}

export async function squareCenter(page, sq) {
  const box = await page.locator('.board-frame').boundingBox()
  const black = await page.locator('.board-frame .cg-wrap').evaluate((el) => el.classList.contains('orientation-black'))
  const f = 'abcdefgh'.indexOf(sq[0])
  const r = Number(sq[1]) - 1
  const size = box.width / 8
  return { x: box.x + ((black ? 7 - f : f) + 0.5) * size, y: box.y + ((black ? r : 7 - r) + 0.5) * size }
}

/**
 * Clicks (or taps) a square. `opts` may be a boolean (legacy: touch) or { touch, frozen }.
 * With `frozen` (Playwright's paused fake clock) Chessground's requestAnimationFrame never fires
 * by itself, so a short runFor() lets it select/move; it costs ~40 ms of fake time per click.
 */
export async function click(page, sq, opts = false) {
  const o = typeof opts === 'object' ? opts : { touch: opts }
  const { x, y } = await squareCenter(page, sq)
  if (o.touch) await page.touchscreen.tap(x, y)
  else await page.mouse.click(x, y)
  if (o.frozen) await page.clock.runFor(40)
}

export async function drag(page, from, to) {
  const a = await squareCenter(page, from)
  const b = await squareCenter(page, to)
  await page.mouse.move(a.x, a.y)
  await page.mouse.down()
  await page.mouse.move((a.x + b.x) / 2, (a.y + b.y) / 2, { steps: 4 })
  await page.mouse.move(b.x, b.y, { steps: 6 })
  await page.mouse.up()
}

export const moveTexts = (page) => page.locator('.moves .move-btn.num').allInnerTexts()

/** Plays "e2e4 e7e5 ..." by clicking (or tapping) and waits for each move to register. */
export async function playClicks(page, line, { touch = false, frozen = false } = {}) {
  for (const mv of line.trim().split(/\s+/)) {
    const before = (await moveTexts(page)).length
    await click(page, mv.slice(0, 2), { touch, frozen })
    await click(page, mv.slice(2, 4), { touch, frozen })
    await until(async () => (await moveTexts(page)).length === before + 1, `lance ${mv} registrado`)
  }
}

export const settle = (page, ms = 350) => page.waitForTimeout(ms) // let piece animations finish

export const clockText = (page, color) => page.locator(`[data-testid=clock-${color}]`).innerText()

/** Opens "Nova partida", picks a mode (e.g. "Blitz") and optionally a preset chip (e.g. "3 min + 2 s"). */
export async function newTimedGame(page, mode, preset) {
  await page.getByRole('button', { name: 'Nova partida' }).first().click()
  await page.getByRole('button', { name: mode, exact: true }).click()
  if (preset) await page.getByRole('button', { name: preset, exact: true }).click()
  await page.getByRole('button', { name: 'Começar partida' }).click()
  await page.locator('dialog[open]').waitFor({ state: 'detached' })
}
