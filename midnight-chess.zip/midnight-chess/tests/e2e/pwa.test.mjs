import { after, before, describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { moveTexts, playClicks, start, until } from './helpers.mjs'

let app
before(async () => {
  app = await start()
})
after(async () => {
  await app?.close()
})

describe('instalável e offline', () => {
  it('manifesto válido, com ícones que carregam', async () => {
    const { page, context } = await app.open()
    const href = await page.locator('link[rel=manifest]').getAttribute('href')
    const res = await page.request.get(new URL(href, app.base).href)
    assert.equal(res.status(), 200)
    const m = await res.json()
    assert.equal(m.display, 'standalone')
    assert.ok(m.icons.some((i) => i.sizes === '192x192') && m.icons.some((i) => i.sizes === '512x512'))
    assert.ok(m.icons.some((i) => i.purpose === 'maskable'))
    for (const icon of m.icons) assert.equal((await page.request.get(new URL(icon.src, app.base).href)).status(), 200, icon.src)
    await context.close()
  })

  it('depois da primeira visita funciona sem rede e mantém a partida salva', async () => {
    const { page, context, problems } = await app.open()
    await page.evaluate(() => navigator.serviceWorker.ready)
    await page.reload()
    await until(() => page.evaluate(() => !!navigator.serviceWorker.controller), 'service worker no controle')
    await playClicks(page, 'e2e4 e7e5')
    await context.setOffline(true)
    await page.reload()
    await page.waitForSelector('cg-board piece')
    assert.deepEqual(await moveTexts(page), ['e4', 'e5'])
    await playClicks(page, 'g1f3')
    assert.equal((await moveTexts(page)).length, 3)
    assert.deepEqual(problems.filter((p) => !/Failed to load resource|net::ERR/.test(p)), [])
    await context.close()
  })
})
