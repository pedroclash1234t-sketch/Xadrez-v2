import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { Chess } from '../../src/engine/chessLib'
import { analyzeMoves } from '../../src/engine/position'
import { agreeDraw, resign } from '../../src/engine/session'
import type { Outcome } from '../../src/engine/types'
import { buildPgn } from '../../src/persistence/record'
import { FOOLS_MATE, SCHOLARS_MATE, newState, play } from './helpers'

const win: Outcome = { result: '1-0', reason: 'resignation', winner: 'w' }

function reload(pgn: string) {
  const c = new Chess()
  c.loadPgn(pgn)
  return c
}

describe('exportação de PGN', () => {
  it('traz as sete etiquetas padrão, resultado no cabeçalho e no fim do texto de lances', () => {
    const s = play(newState(), ...SCHOLARS_MATE)
    const pgn = buildPgn(s, { result: '1-0', reason: 'checkmate', winner: 'w' })
    for (const tag of ['Event', 'Site', 'Date', 'Round', 'White', 'Black', 'Result']) assert.match(pgn, new RegExp(`\\[${tag} "`), tag)
    assert.match(pgn, /\[Date "2026\.10\.16"\]/)
    assert.match(pgn, /\[Result "1-0"\]/)
    assert.match(pgn, /1\. e4 e5 2\. Qh5 Nc6 3\. Bc4 Nf6 4\. Qxf7# 1-0$/)
  })

  it('preserva roque, captura com promoção e xeque, en passant e mate: recarregar dá a mesma posição e os mesmos lances', () => {
    const games: string[][] = [
      ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Bc5', 'O-O', 'Nf6'], // roque curto
      ['d4', 'd5', 'Nc3', 'Nf6', 'Bf4', 'e6', 'Qd2', 'Be7', 'O-O-O', 'O-O'], // roque longo dos dois lados
      ['e4', 'a6', 'e5', 'd5', 'exd6'], // en passant
      ['a4', 'b5', 'axb5', 'a6', 'bxa6', 'Nf6', 'a7', 'h6', 'axb8=N'], // promoção com captura
      ['a4', 'b5', 'axb5', 'a6', 'bxa6', 'Nf6', 'a7', 'h6', 'axb8=Q'], // promoção a dama
      FOOLS_MATE,
    ]
    for (const sans of games) {
      const s = play(newState(), ...sans)
      const pgn = buildPgn(s, win)
      const c = reload(pgn)
      assert.deepEqual(c.history(), s.moves.map((m) => m.san), sans.join(' '))
      assert.equal(c.fen(), analyzeMoves(s.moves).fen)
    }
    assert.match(buildPgn(play(newState(), ...games[3]), win), /axb8=N/)
    assert.match(buildPgn(play(newState(), ...games[0]), win), /O-O/)
  })

  it('desistência, acordo e partida sem lances usam o resultado informado', () => {
    const resigned = resign(play(newState(), 'e4', 'e5'), 'b')
    assert.match(buildPgn(resigned, { result: '1-0', reason: 'resignation', winner: 'w' }), /\[Result "1-0"\][\s\S]*1\. e4 e5 1-0$/)
    const drawn = agreeDraw(play(newState(), 'd4', 'd5'))
    const pgn = buildPgn(drawn, { result: '1/2-1/2', reason: 'agreement' })
    assert.match(pgn, /1\. d4 d5 1\/2-1\/2$/)
    assert.equal(reload(pgn).history().length, 2)
    const empty = buildPgn(newState(), { result: '0-1', reason: 'resignation', winner: 'b' })
    assert.match(empty, /\[Result "0-1"\]/)
  })

  it('nomes com caracteres especiais não quebram o arquivo', () => {
    const s = play(newState(), 'e4')
    s.players.w = 'Zé "O Rei" [Silva]\nLima'
    s.players.b = 'José \\ Cruz'
    const pgn = buildPgn(s, win)
    assert.equal(reload(pgn).getHeaders().Black, 'José \\ Cruz'.replace(/\\/g, "'"))
    assert.equal(reload(pgn).history().length, 1)
  })

  it('o PGN não altera a partida original', () => {
    const s = play(newState(), 'e4', 'e5')
    const before = JSON.stringify(s)
    buildPgn(s, win)
    assert.equal(JSON.stringify(s), before)
  })
})
