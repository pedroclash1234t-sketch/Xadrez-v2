import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { timeLeftOf } from '../../src/engine/session'
import { parseSession } from '../../src/persistence/schema'
import { KEYS } from '../../src/persistence/storage'
import { BLITZ_3_2, BULLET_1_0, FOOLS_MATE, KNIGHT_SHUFFLE, LONE_KING_LINE, MemoryStorage, RAPID_10_0, clockEnv, newStore } from './helpers'
import type { GameStore } from '../../src/store/gameStore'
import { Chess } from '../../src/engine/chessLib'

function setup(control = BLITZ_3_2) {
  const c = clockEnv()
  const storage = new MemoryStorage()
  const { store } = newStore(storage, c.env)
  store.newGame({ w: 'Ana', b: 'Beto' }, control)
  return { c, storage, store }
}

/** Plays SAN moves through the store, advancing the fake clock by `stepMs` before each one. */
function playSans(store: GameStore, c: ReturnType<typeof clockEnv>, sans: string[], stepMs = 0) {
  for (const san of sans) {
    c.advance(stepMs)
    const chess = new Chess()
    for (const m of store.getState().moves) chess.move({ from: m.from, to: m.to, promotion: m.promotion })
    const mv = chess.move(san)
    assert.equal(store.move(mv.from, mv.to, mv.promotion as 'q' | undefined), 'ok', san)
  }
}

describe('novo jogo e reinício com relógio', () => {
  it('cria a partida com o controle escolhido e o reinício o mantém', () => {
    const { store, c } = setup()
    assert.deepEqual(store.getSnapshot().game.clock?.control, BLITZ_3_2)
    assert.equal(store.getSnapshot().canLeave, true) // ainda sem lances
    store.restart()
    assert.deepEqual(store.getSnapshot().game.clock?.control, BLITZ_3_2)
    playSans(store, c, ['e4', 'e5'])
    store.resign('b')
    store.restart() // terminou: pode recomeçar
    const g = store.getSnapshot().game
    assert.deepEqual(g.clock?.control, BLITZ_3_2)
    assert.deepEqual(g.clock?.remaining, { w: 180_000, b: 180_000 })
    assert.equal(g.moves.length, 0)
  })

  it('partida com relógio em andamento não pode ser abandonada por "Nova partida" nem "Reiniciar"', () => {
    const { store, c } = setup()
    playSans(store, c, ['e4'])
    const id = store.getSnapshot().game.id
    assert.equal(store.getSnapshot().canLeave, false)
    store.newGame({ w: 'X', b: 'Y' })
    assert.equal(store.getSnapshot().game.id, id)
    assert.equal(store.getSnapshot().notice?.kind, 'warning')
    assert.match(store.getSnapshot().notice?.text ?? '', /Desistir/)
    store.restart()
    assert.equal(store.getSnapshot().game.id, id)
    assert.equal(store.getSnapshot().game.moves.length, 1)
  })

  it('desfazer e refazer não fazem nada com relógio', () => {
    const { store, c } = setup()
    playSans(store, c, ['e4', 'e5'])
    store.undo()
    store.redo()
    assert.equal(store.getSnapshot().game.moves.length, 2)
    assert.equal(store.getSnapshot().canUndo, false)
    assert.equal(store.getSnapshot().canRedo, false)
  })

  it('partida sem relógio continua como antes', () => {
    const c = clockEnv()
    const { store } = newStore(new MemoryStorage(), c.env)
    playSans(store, c, ['e4', 'e5'])
    assert.equal(store.getSnapshot().game.clock, null)
    assert.equal(store.getSnapshot().canUndo, true)
    store.undo()
    assert.equal(store.getSnapshot().game.moves.length, 1)
    store.restart() // com progresso e sem relógio: permitido (a interface pede confirmação)
    assert.equal(store.getSnapshot().game.moves.length, 0)
  })
})

describe('tempo esgotado', () => {
  it('tick() encerra a partida no instante certo, uma única vez, e arquiva com o controle de tempo', () => {
    const { store, c, storage } = setup()
    playSans(store, c, ['e4']) // relógio das pretas começa
    c.advance(179_999)
    assert.equal(store.tick(), false)
    c.advance(1)
    assert.equal(store.tick(), true)
    const s = store.getSnapshot()
    assert.deepEqual(s.outcome, { result: '1-0', reason: 'timeout', winner: 'w', flagged: 'b' })
    assert.equal(s.finished, true)
    assert.match(s.notice?.text ?? '', /Beto ficou sem tempo/)
    assert.equal(store.tick(), false)
    assert.equal(s.history.length, 1)
    const rec = s.history[0]
    assert.equal(rec.reason, 'timeout')
    assert.equal(rec.flagged, 'b')
    assert.deepEqual(rec.timeControl, BLITZ_3_2)
    assert.match(rec.pgn, /\[TimeControl "180\+2"\]/)
    assert.match(rec.pgn, /\[Termination "time forfeit"\]/)
    // recarregar não duplica
    assert.equal(newStore(storage, c.env).store.getSnapshot().history.length, 1)
  })

  it('lance feito depois de o tempo acabar (sem nenhum tick) é recusado e a derrota por tempo vale', () => {
    const { store, c } = setup()
    playSans(store, c, ['e4'])
    c.advance(200_000)
    assert.equal(store.move('e7', 'e5'), 'rejected')
    const s = store.getSnapshot()
    assert.equal(s.game.moves.length, 1)
    assert.equal(s.outcome?.reason, 'timeout')
  })

  it('desistir depois de o tempo acabar: vale o tempo, não a desistência', () => {
    const { store, c } = setup()
    playSans(store, c, ['e4'])
    c.advance(200_000)
    store.resign('w')
    assert.equal(store.getSnapshot().outcome?.reason, 'timeout')
    assert.equal(store.getSnapshot().outcome?.winner, 'w')
  })

  it('partida terminada por mate com relógio é arquivada com o controle', () => {
    const { store, c } = setup()
    playSans(store, c, FOOLS_MATE, 2_000)
    const rec = store.getSnapshot().history[0]
    assert.equal(rec.reason, 'checkmate')
    assert.deepEqual(rec.timeControl, BLITZ_3_2)
    assert.equal(store.getSnapshot().game.clock?.since, null)
  })

  it('reivindicar empate encerra e para o relógio', () => {
    const { store, c } = setup()
    playSans(store, c, [...KNIGHT_SHUFFLE, ...KNIGHT_SHUFFLE], 1_000)
    assert.equal(store.getSnapshot().canClaimDraw, true)
    store.claimDraw()
    assert.equal(store.getSnapshot().outcome?.reason, 'threefold-claimed')
    assert.equal(store.getSnapshot().game.clock?.since, null)
  })
})

describe('pausa e reabertura do app', () => {
  it('pausa automática trava os lances, não cobra o tempo parado e retoma sob comando', () => {
    const { store, c } = setup()
    playSans(store, c, ['e4'])
    c.advance(10_000)
    store.autoPause()
    assert.equal(store.getSnapshot().paused, true)
    assert.equal(store.getSnapshot().canPlay, false)
    assert.equal(store.move('e7', 'e5'), 'rejected')
    assert.match(store.getSnapshot().notice?.text ?? '', /pausada/)
    c.advance(600_000) // dez minutos longe do app
    assert.equal(store.tick(), false)
    store.resume()
    assert.equal(store.getSnapshot().paused, false)
    assert.equal(timeLeftOf(store.getState(), 'b', c.time), 170_000) // só os 10 s antes da pausa
    c.advance(5_000)
    assert.equal(store.move('e7', 'e5'), 'ok')
  })

  it('autoPause antes do primeiro lance não faz nada', () => {
    const { store } = setup()
    store.autoPause()
    assert.equal(store.getSnapshot().paused, false)
  })

  it('pausa manual: negada em Bullet/Blitz, permitida em Rápido', () => {
    const blitz = setup(BLITZ_3_2)
    playSans(blitz.store, blitz.c, ['e4'])
    blitz.store.pause()
    assert.equal(blitz.store.getSnapshot().paused, false)
    assert.match(blitz.store.getSnapshot().notice?.text ?? '', /Rápido e Clássico/)

    const bullet = setup(BULLET_1_0)
    playSans(bullet.store, bullet.c, ['e4'])
    bullet.store.pause()
    assert.equal(bullet.store.getSnapshot().paused, false)

    const rapid = setup(RAPID_10_0)
    rapid.store.pause() // antes do 1º lance: nada a pausar
    assert.equal(rapid.store.getSnapshot().paused, false)
    playSans(rapid.store, rapid.c, ['e4'])
    rapid.store.pause()
    assert.equal(rapid.store.getSnapshot().paused, true)
    assert.equal(rapid.store.getSnapshot().game.clock?.paused, 'manual')
  })

  it('reabrir o app: volta pausada, sem cobrar o tempo desde o último lance, e continua de onde parou', () => {
    const { store, c, storage } = setup()
    playSans(store, c, ['e4'])
    c.advance(30_000) // pretas pensando; app fechado sem avisar
    c.advance(3_600_000)
    const reopened = newStore(storage, c.env).store
    const g = reopened.getSnapshot().game
    assert.equal(g.clock?.paused, 'restore')
    assert.equal(g.clock?.since, null)
    assert.equal(g.clock?.remaining.b, 180_000)
    assert.equal(reopened.getSnapshot().canPlay, false)
    // abrir de novo mantém a mesma pausa
    assert.equal(newStore(storage, c.env).store.getSnapshot().game.clock?.paused, 'restore')
    reopened.resume()
    c.advance(10_000)
    assert.equal(timeLeftOf(reopened.getState(), 'b', c.time), 170_000)
    assert.equal(reopened.move('e7', 'e5'), 'ok')
  })

  it('o estado salvo de uma partida com relógio passa na validação de ida e volta', () => {
    const { store, c, storage } = setup(RAPID_10_0)
    playSans(store, c, ['e4', 'e5', 'Nf3'], 3_000)
    store.pause()
    const raw = JSON.parse(storage.getItem(KEYS.current) ?? '{}')
    assert.equal(raw.version, 2)
    const parsed = parseSession(raw)
    assert.ok(parsed.ok)
    if (parsed.ok) assert.deepEqual(parsed.value.clock, store.getState().clock)
  })

  it('relógio com valores impossíveis salvos é rejeitado (não vira partida corrompida)', () => {
    const { store, c, storage } = setup()
    playSans(store, c, ['e4'])
    const raw = JSON.parse(storage.getItem(KEYS.current) ?? '{}')
    for (const mutate of [
      (r: typeof raw) => (r.session.clock.remaining.w = -5),
      (r: typeof raw) => (r.session.clock.remaining.b = 9e12),
      (r: typeof raw) => (r.session.clock.control.baseMs = 5),
      (r: typeof raw) => (r.session.clock.paused = 'quem-sabe'),
      (r: typeof raw) => (r.session.clock.since = 'ontem'),
    ]) {
      const bad = structuredClone(raw)
      mutate(bad)
      assert.equal(parseSession(bad).ok, false)
    }
  })
})

describe('clique duplicado', () => {
  it('o mesmo lance chegando duas vezes seguidas é ignorado sem mensagem de erro', () => {
    const c = clockEnv()
    const { store } = newStore(new MemoryStorage(), c.env)
    assert.equal(store.move('e2', 'e4'), 'ok')
    assert.equal(store.move('e2', 'e4'), 'duplicate')
    assert.equal(store.getSnapshot().notice, null)
    assert.equal(store.getSnapshot().game.moves.length, 1)
  })

  it('depois da janela, repetir o lance ilegal volta a ser erro; outros lances ilegais sempre são erro', () => {
    const c = clockEnv()
    const { store } = newStore(new MemoryStorage(), c.env)
    store.move('e2', 'e4')
    assert.equal(store.move('d2', 'd5'), 'rejected') // outro lance ilegal
    assert.equal(store.getSnapshot().notice?.kind, 'error')
    c.advance(700)
    assert.equal(store.move('e2', 'e4'), 'rejected')
    assert.equal(store.getSnapshot().notice?.kind, 'error')
    assert.equal(store.move('e7', 'e5'), 'ok') // o jogo continua normalmente
  })

  it('não mascara lance legal: a mesma casa de origem e destino legal pelo outro lado é aceita', () => {
    const c = clockEnv()
    const { store } = newStore(new MemoryStorage(), c.env)
    store.move('g1', 'f3')
    store.move('g8', 'f6')
    store.move('f3', 'g1')
    store.move('f6', 'g8')
    assert.equal(store.move('g1', 'f3'), 'ok') // mesmo par origem/destino do primeiro lance, agora legítimo
    assert.equal(store.getSnapshot().game.moves.length, 5)
  })
})

describe('registros por tempo esgotado sobrevivem ao recarregar (regressão)', () => {
  it('derrota por tempo e empate por tempo sem material voltam do armazenamento intactos', () => {
    const { store, c, storage } = setup(RAPID_10_0)
    playSans(store, c, ['e4'])
    c.advance(600_000)
    store.tick()
    const winRec = store.getSnapshot().history[0]
    assert.equal(winRec.reason, 'timeout')

    store.restart()
    playSans(store, c, LONE_KING_LINE.slice(0, 1))
    // partida de material insuficiente: a mesma sequência real usada nos testes de relógio
    store.resign('w')
    store.restart()
    for (const san of LONE_KING_LINE) {
      const chess = new Chess()
      for (const m of store.getState().moves) chess.move({ from: m.from, to: m.to, promotion: m.promotion })
      const mv = chess.move(san)
      assert.equal(store.move(mv.from, mv.to, mv.promotion as 'q' | undefined), 'ok', san)
    }
    c.advance(700_000)
    assert.equal(store.tick(), true)
    const drawRec = store.getSnapshot().history[0]
    assert.equal(drawRec.reason, 'timeout-insufficient')
    assert.equal(drawRec.result, '1/2-1/2')
    assert.equal(drawRec.flagged, 'b')

    const again = newStore(storage, c.env).store.getSnapshot().history
    assert.equal(again.length, 3)
    assert.deepEqual(again.find((g) => g.id === winRec.id), winRec)
    assert.deepEqual(again.find((g) => g.id === drawRec.id), drawRec)
  })
})
