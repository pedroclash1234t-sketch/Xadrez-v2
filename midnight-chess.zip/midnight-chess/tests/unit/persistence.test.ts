import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { Chess } from '../../src/engine/chessLib'
import { analyzeMoves, replay } from '../../src/engine/position'
import { buildRecord, computeStats } from '../../src/persistence/record'
import { SCHEMA_VERSION, parseGameRecord } from '../../src/persistence/schema'
import { KEYS, Persistence } from '../../src/persistence/storage'
import { FOOLS_MATE, KNIGHT_SHUFFLE, MemoryStorage, SCHOLARS_MATE, newState, newStore, play, testEnv } from './helpers'

const playAll = (store: ReturnType<typeof newStore>['store'], sans: string[]) => {
  for (const san of sans) {
    const chess = new Chess()
    for (const m of store.getState().moves) chess.move({ from: m.from, to: m.to, promotion: m.promotion })
    const mv = chess.move(san)
    assert.equal(store.move(mv.from, mv.to, mv.promotion as 'q' | undefined), 'ok', san)
  }
}

describe('salvamento automático e recuperação', () => {
  it('salva a cada lance válido e recupera ao reabrir', () => {
    const storage = new MemoryStorage()
    const a = newStore(storage)
    playAll(a.store, ['e4', 'e5', 'Nf3'])
    const saved = storage.getItem(KEYS.current)
    assert.ok(saved)
    assert.equal(JSON.parse(saved).session.moves.length, 3)

    const b = newStore(storage) // "recarregar a página"
    const s = b.store.getSnapshot()
    assert.deepEqual(s.game.moves.map((m) => m.san), ['e4', 'e5', 'Nf3'])
    assert.equal(s.game.id, a.store.getSnapshot().game.id)
    assert.equal(s.view.fen, a.store.getSnapshot().view.fen)
    assert.equal(s.canPlay, true)
  })

  it('lance ilegal não é salvo nem altera a partida', () => {
    const storage = new MemoryStorage()
    const { store } = newStore(storage)
    store.move('e2', 'e4')
    const before = storage.getItem(KEYS.current)
    assert.equal(store.move('e2', 'e5'), 'rejected')
    assert.equal(storage.getItem(KEYS.current), before)
    assert.equal(store.getSnapshot().game.moves.length, 1)
    assert.equal(store.getSnapshot().notice?.kind, 'error')
  })

  it('preserva nomes, orientação e lances para refazer', () => {
    const storage = new MemoryStorage()
    const a = newStore(storage)
    a.store.newGame({ w: 'Ana', b: 'Beto' })
    playAll(a.store, ['d4', 'd5', 'c4'])
    a.store.flip()
    a.store.undo()
    const b = newStore(storage)
    const g = b.store.getSnapshot().game
    assert.deepEqual(g.players, { w: 'Ana', b: 'Beto' })
    assert.equal(g.orientation, 'b')
    assert.equal(g.moves.length, 2)
    assert.equal(g.redo.length, 1)
    b.store.redo()
    assert.equal(b.store.getSnapshot().game.moves.length, 3)
  })

  it('reiniciar mantém os jogadores e começa uma partida nova', () => {
    const { store } = newStore()
    store.newGame({ w: 'Ana', b: 'Beto' })
    store.move('e2', 'e4')
    const oldId = store.getSnapshot().game.id
    store.restart()
    const s = store.getSnapshot()
    assert.notEqual(s.game.id, oldId)
    assert.equal(s.game.moves.length, 0)
    assert.deepEqual(s.game.players, { w: 'Ana', b: 'Beto' })
    assert.equal(s.hasProgress, false)
  })
})

describe('histórico de partidas concluídas', () => {
  it('arquiva o mate com todos os dados e permite reproduzir os lances', () => {
    const { store, storage } = newStore()
    store.newGame({ w: 'Ana', b: 'Beto' })
    playAll(store, SCHOLARS_MATE)
    const s = store.getSnapshot()
    assert.equal(s.finished, true)
    assert.equal(s.history.length, 1)
    const rec = s.history[0]
    assert.equal(rec.id, s.game.id)
    assert.equal(rec.result, '1-0')
    assert.equal(rec.reason, 'checkmate')
    assert.equal(rec.white, 'Ana')
    assert.equal(rec.black, 'Beto')
    assert.equal(rec.plies, 7)
    assert.equal(rec.moveCount, 4)
    assert.ok(!Number.isNaN(Date.parse(rec.startedAt)) && !Number.isNaN(Date.parse(rec.endedAt)))
    assert.ok(rec.pgn.includes('[White "Ana"]') && rec.pgn.includes('[Result "1-0"]') && rec.pgn.includes('Qxf7#'))

    // reprodução lance a lance reconstrói a posição final
    assert.equal(replay(rec.moves).chess.fen(), rec.finalFen)
    assert.equal(replay(rec.moves, 3).chess.fen(), analyzeMoves(rec.moves, 3).fen)
    // o PGN salvo é aceito pelo chess.js e dá a mesma posição final
    const fromPgn = new Chess()
    fromPgn.loadPgn(rec.pgn)
    assert.equal(fromPgn.fen(), rec.finalFen)

    // e sobrevive a recarregar
    const again = newStore(storage).store.getSnapshot()
    assert.equal(again.history.length, 1)
    assert.deepEqual(again.history[0], rec)
  })

  it('restaurar uma partida terminada não duplica o registro', () => {
    const storage = new MemoryStorage()
    const first = newStore(storage)
    playAll(first.store, FOOLS_MATE)
    for (let i = 0; i < 3; i++) {
      const s = newStore(storage).store.getSnapshot()
      assert.equal(s.finished, true)
      assert.equal(s.history.length, 1)
    }
  })

  it('arquiva uma partida terminada que ainda não estava no histórico (queda entre duas gravações)', () => {
    const env = testEnv()
    const storage = new MemoryStorage()
    const p = new Persistence(storage, env.now)
    p.saveCurrent(play(newState(env), ...FOOLS_MATE)) // só a gravação "current" aconteceu
    const s = newStore(storage, env).store.getSnapshot()
    assert.equal(s.history.length, 1)
    assert.equal(newStore(storage, env).store.getSnapshot().history.length, 1)
  })

  it('excluir a partida recém-terminada não a faz reaparecer ao recarregar', () => {
    const storage = new MemoryStorage()
    const env = testEnv() // mesmo relógio e mesma sequência de ids entre as "aberturas" do app
    const a = newStore(storage, env)
    playAll(a.store, FOOLS_MATE)
    assert.equal(a.store.getSnapshot().history.length, 1)
    a.store.deleteGame(a.store.getSnapshot().game.id)
    assert.equal(a.store.getSnapshot().history.length, 0)
    for (let i = 0; i < 2; i++) {
      const b = newStore(storage, env).store.getSnapshot()
      assert.equal(b.finished, true) // a partida terminada continua exibida
      assert.equal(b.history.length, 0) // mas não volta ao histórico
    }
    // e uma partida nova depois dela arquiva normalmente
    const c = newStore(storage, env)
    c.store.newGame()
    playAll(c.store, SCHOLARS_MATE)
    assert.equal(c.store.getSnapshot().history.length, 1)
  })

  it('upsert pelo mesmo id substitui em vez de duplicar', () => {
    const env = testEnv()
    const p = new Persistence(new MemoryStorage(), env.now)
    const g = play(newState(env), ...FOOLS_MATE)
    const rec = buildRecord(g, { result: '0-1', reason: 'checkmate', winner: 'b' }, env.now())
    p.upsertGame(rec)
    p.upsertGame(rec)
    assert.equal(p.loadHistory().games.length, 1)
  })

  it('desistência, acordo e reivindicação também são arquivados, com o motivo', () => {
    const a = newStore()
    playAll(a.store, ['e4', 'e5'])
    a.store.resign('b')
    assert.equal(a.store.getSnapshot().history[0].reason, 'resignation')
    assert.equal(a.store.getSnapshot().history[0].result, '1-0')

    a.store.newGame()
    a.store.move('e2', 'e4')
    a.store.agreeDraw()
    assert.equal(a.store.getSnapshot().history[0].reason, 'agreement')

    a.store.newGame()
    playAll(a.store, [...KNIGHT_SHUFFLE, ...KNIGHT_SHUFFLE])
    assert.equal(a.store.getSnapshot().canClaimDraw, true)
    a.store.claimDraw()
    assert.equal(a.store.getSnapshot().history[0].reason, 'threefold-claimed')
    assert.equal(a.store.getSnapshot().history.length, 3)
  })

  it('reivindicar sem direito não encerra a partida', () => {
    const { store } = newStore()
    playAll(store, ['e4'])
    store.claimDraw()
    assert.equal(store.getSnapshot().finished, false)
    assert.equal(store.getSnapshot().notice?.kind, 'warning')
  })

  it('excluir remove só a partida escolhida e persiste', () => {
    const storage = new MemoryStorage()
    const { store } = newStore(storage)
    playAll(store, FOOLS_MATE)
    store.newGame()
    playAll(store, SCHOLARS_MATE)
    const [latest, older] = store.getSnapshot().history
    store.deleteGame(older.id)
    assert.deepEqual(store.getSnapshot().history.map((g) => g.id), [latest.id])
    assert.deepEqual(newStore(storage).store.getSnapshot().history.map((g) => g.id), [latest.id])
  })

  it('estatísticas básicas', () => {
    const env = testEnv()
    const mk = (sans: string[], result: '1-0' | '0-1' | '1/2-1/2', reason: 'checkmate' | 'agreement') =>
      buildRecord(play(newState(env), ...sans), { result, reason }, env.now())
    const games = [mk(SCHOLARS_MATE, '1-0', 'checkmate'), mk(FOOLS_MATE, '0-1', 'checkmate'), mk(['e4', 'e5'], '1/2-1/2', 'agreement')]
    assert.deepEqual(computeStats(games), { total: 3, whiteWins: 1, blackWins: 1, draws: 1, averageMoves: 2.3 })
    assert.deepEqual(computeStats([]), { total: 0, whiteWins: 0, blackWins: 0, draws: 0, averageMoves: 0 })
  })

  it('nomes com aspas ou colchetes não quebram o PGN', () => {
    const env = testEnv()
    const g = play(newState(env), 'f3', 'e5', 'g4', 'Qh4#')
    g.players.w = 'A"na] [x'
    const rec = buildRecord(g, { result: '0-1', reason: 'checkmate', winner: 'b' }, env.now())
    const c = new Chess()
    c.loadPgn(rec.pgn)
    assert.equal(c.fen(), rec.finalFen)
  })
})

describe('dados inválidos, incompatíveis e falhas de armazenamento', () => {
  it('JSON corrompido na partida em andamento: guarda à parte, começa limpo e avisa', () => {
    const storage = new MemoryStorage()
    storage.setItem(KEYS.current, '{"version":1,"session":{')
    const s = newStore(storage).store.getSnapshot()
    assert.equal(s.game.moves.length, 0)
    assert.equal(s.notice?.kind, 'warning')
    assert.match(s.notice?.text ?? '', /não pôde ser recuperada/)
    assert.equal(storage.getItem(`${KEYS.current}:corrupt`), '{"version":1,"session":{')
  })

  it('lances impossíveis salvos são rejeitados (o chess.js é a autoridade)', () => {
    const storage = new MemoryStorage()
    const bad = { version: 1, savedAt: new Date().toISOString(), session: {
      id: 'x', startedAt: new Date().toISOString(), players: { w: 'A', b: 'B' }, orientation: 'w', manualOutcome: null, redo: [],
      moves: [{ san: 'e4', from: 'e2', to: 'e4' }, { san: 'Ke4', from: 'e8', to: 'e4' }],
    } }
    storage.setItem(KEYS.current, JSON.stringify(bad))
    const p = new Persistence(storage)
    assert.equal(p.loadCurrent().status, 'invalid')
  })

  it('SAN que não corresponde ao lance também é rejeitado', () => {
    const storage = new MemoryStorage()
    const bad = { version: 1, savedAt: new Date().toISOString(), session: {
      id: 'x', startedAt: new Date().toISOString(), players: { w: 'A', b: 'B' }, orientation: 'w', manualOutcome: null, redo: [],
      moves: [{ san: 'e5', from: 'e2', to: 'e4' }],
    } }
    storage.setItem(KEYS.current, JSON.stringify(bad))
    assert.equal(new Persistence(storage).loadCurrent().status, 'invalid')
  })

  it('versão mais nova do formato: não lê, não sobrescreve às cegas', () => {
    const storage = new MemoryStorage()
    const future = JSON.stringify({ version: 99, session: { anything: true } })
    storage.setItem(KEYS.current, future)
    const { store } = newStore(storage)
    assert.match(store.getSnapshot().notice?.text ?? '', /mais nova/)
    assert.equal(storage.getItem(`${KEYS.current}:v99`), future)
    // a partida nova é salva normalmente na versão atual
    assert.equal(JSON.parse(storage.getItem(KEYS.current) ?? '{}').version, SCHEMA_VERSION)
  })

  it('sem versão: inválido', () => {
    const storage = new MemoryStorage()
    storage.setItem(KEYS.current, JSON.stringify({ session: {} }))
    assert.equal(new Persistence(storage).loadCurrent().status, 'invalid')
  })

  it('histórico: registros inválidos e duplicados são descartados, os bons ficam', () => {
    const env = testEnv()
    const storage = new MemoryStorage()
    const p = new Persistence(storage, env.now)
    const good = buildRecord(play(newState(env), ...FOOLS_MATE), { result: '0-1', reason: 'checkmate', winner: 'b' }, env.now())
    const wrongResult = { ...good, id: 'other', result: '1-0' }
    const wrongFen = { ...good, id: 'other2', finalFen: 'x' }
    storage.setItem(KEYS.history, JSON.stringify({ version: 1, games: [good, good, wrongResult, wrongFen, 42, null, { id: 'q' }] }))
    const h = p.loadHistory()
    assert.deepEqual(h.games.map((g) => g.id), [good.id])
    assert.match(h.warnings[0], /6 partida\(s\)/)
  })

  it('histórico ilegível: começa vazio, guarda a cópia e avisa', () => {
    const storage = new MemoryStorage()
    storage.setItem(KEYS.history, 'não é json')
    const h = new Persistence(storage).loadHistory()
    assert.deepEqual(h.games, [])
    assert.equal(h.warnings.length, 1)
    assert.equal(storage.getItem(`${KEYS.history}:corrupt`), 'não é json')
  })

  it('falha ao gravar (cota cheia): a partida continua e a interface é avisada', () => {
    const storage = new MemoryStorage()
    const { store } = newStore(storage)
    storage.failWrites = true
    assert.equal(store.move('e2', 'e4'), 'ok')
    const s = store.getSnapshot()
    assert.equal(s.game.moves.length, 1)
    assert.match(s.storage.error ?? '', /Não foi possível salvar/)
    storage.failWrites = false
    store.move('e7', 'e5')
    assert.equal(store.getSnapshot().storage.error, null)
  })

  it('sem armazenamento disponível: tudo funciona em memória e avisa', () => {
    const { store } = newStore(null)
    assert.equal(store.getSnapshot().storage.available, false)
    assert.ok(store.getSnapshot().storage.error)
    assert.equal(store.move('e2', 'e4'), 'ok')
    store.undo()
    assert.equal(store.getSnapshot().game.moves.length, 0)
  })

  it('registro com contagem de lances adulterada é recusado', () => {
    const env = testEnv()
    const good = buildRecord(play(newState(env), ...FOOLS_MATE), { result: '0-1', reason: 'checkmate', winner: 'b' }, env.now())
    assert.equal(parseGameRecord(good).ok, true)
    assert.equal(parseGameRecord({ ...good, plies: 99 }).ok, false)
    assert.equal(parseGameRecord({ ...good, moves: good.moves.slice(0, 3) }).ok, false)
  })
})
