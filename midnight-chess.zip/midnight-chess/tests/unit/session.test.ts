import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { analyzeMoves } from '../../src/engine/position'
import {
  agreeDraw, canPlay, canRedo, canUndo, createGame, flip, hasProgress, isLive, navigate, outcomeOf,
  playMove, redo, resign, undo, viewAnalysis,
} from '../../src/engine/session'
import { FOOLS_MATE, newState, play, testEnv } from './helpers'

describe('desfazer e refazer', () => {
  it('desfazer devolve a posição anterior e guarda o lance para refazer', () => {
    const s3 = play(newState(), 'e4', 'e5', 'Nf3')
    const s2 = undo(s3)
    assert.equal(s2.moves.length, 2)
    assert.equal(s2.redo.length, 1)
    assert.equal(analyzeMoves(s2.moves).fen, analyzeMoves(s3.moves, 2).fen)
    assert.equal(analyzeMoves(s2.moves).turn, 'w')
    assert.equal(s2.viewIndex, 2)
  })

  it('refazer restaura exatamente o estado anterior', () => {
    const s3 = play(newState(), 'e4', 'e5', 'Nf3')
    const back = redo(undo(s3))
    assert.deepEqual(back.moves, s3.moves)
    assert.equal(analyzeMoves(back.moves).fen, analyzeMoves(s3.moves).fen)
    assert.equal(back.redo.length, 0)
  })

  it('desfazer várias vezes e refazer na ordem certa', () => {
    const s = play(newState(), 'd4', 'd5', 'c4', 'e6')
    const u = undo(undo(undo(s)))
    assert.deepEqual(u.moves.map((m) => m.san), ['d4'])
    const r = redo(redo(u))
    assert.deepEqual(r.moves.map((m) => m.san), ['d4', 'd5', 'c4'])
  })

  it('um lance novo descarta o que havia para refazer', () => {
    const u = undo(play(newState(), 'e4', 'e5'))
    assert.equal(canRedo(u), true)
    const s = play(u, 'c5')
    assert.equal(s.redo.length, 0)
    assert.equal(canRedo(s), false)
    assert.deepEqual(s.moves.map((m) => m.san), ['e4', 'c5'])
  })

  it('sem lances ou sem o que refazer, nada acontece', () => {
    const s = newState()
    assert.equal(canUndo(s), false)
    assert.equal(undo(s), s)
    assert.equal(redo(s), s)
  })
})

describe('navegação pelos lances', () => {
  const s = play(newState(), 'e4', 'e5', 'Nf3', 'Nc6')

  it('mostra a posição de cada lance sem alterar a partida', () => {
    const at2 = navigate(s, 2)
    assert.equal(at2.viewIndex, 2)
    assert.deepEqual(at2.moves, s.moves)
    assert.equal(viewAnalysis(at2).fen, analyzeMoves(s.moves, 2).fen)
    assert.deepEqual(viewAnalysis(at2).lastMove, ['e7', 'e5'])
  })

  it('primeiro, anterior, próximo e último respeitam os limites', () => {
    assert.equal(navigate(s, 'first').viewIndex, 0)
    assert.equal(navigate(navigate(s, 'first'), 'prev').viewIndex, 0)
    assert.equal(navigate(s, 'prev').viewIndex, 3)
    assert.equal(navigate(s, 'next').viewIndex, 4)
    assert.equal(navigate(navigate(s, 'first'), 'last').viewIndex, 4)
    assert.equal(navigate(s, 99).viewIndex, 4)
    assert.equal(navigate(s, -5).viewIndex, 0)
  })

  it('posição inicial não tem último lance', () => {
    assert.equal(viewAnalysis(navigate(s, 'first')).lastMove, null)
  })

  it('não se joga enquanto se vê uma posição antiga', () => {
    const past = navigate(s, 1)
    assert.equal(isLive(past), false)
    assert.equal(canPlay(past), false)
    assert.deepEqual(playMove(past, { from: 'd2', to: 'd4' }), { ok: false, error: 'not-live' })
  })

  it('desfazer estando em posição antiga age sobre o último lance e volta ao fim', () => {
    const past = navigate(s, 1)
    const u = undo(past)
    assert.deepEqual(u.moves.map((m) => m.san), ['e4', 'e5', 'Nf3'])
    assert.equal(u.viewIndex, 3)
  })
})

describe('encerramento e reinício', () => {
  it('desistência dá a vitória ao adversário e bloqueia a partida', () => {
    const s = resign(play(newState(), 'e4', 'e5'), 'b')
    assert.deepEqual(outcomeOf(s), { result: '1-0', reason: 'resignation', winner: 'w' })
    assert.equal(canPlay(s), false)
    assert.equal(canUndo(s), false)
  })

  it('não é possível desistir nem empatar depois do fim', () => {
    const mate = play(newState(), ...FOOLS_MATE)
    assert.equal(resign(mate, 'w'), mate)
    assert.equal(agreeDraw(mate), mate)
  })

  it('hasProgress só vale com lances e partida em andamento', () => {
    assert.equal(hasProgress(newState()), false)
    const s = play(newState(), 'e4')
    assert.equal(hasProgress(s), true)
    assert.equal(hasProgress(resign(s, 'b')), false)
  })

  it('nova partida: id novo, tabuleiro limpo, nomes saneados', () => {
    const env = testEnv()
    const a = createGame(env, { w: '  Ana   Lima ', b: '' })
    const b = createGame(env, a.players)
    assert.notEqual(a.id, b.id)
    assert.deepEqual(a.players, { w: 'Ana Lima', b: 'Pretas' })
    assert.equal(b.moves.length, 0)
    assert.equal(analyzeMoves(b.moves).fen, analyzeMoves([]).fen)
  })

  it('girar o tabuleiro não mexe nos lances', () => {
    const s = play(newState(), 'e4')
    const f = flip(s)
    assert.equal(f.orientation, 'b')
    assert.deepEqual(f.moves, s.moves)
    assert.equal(flip(f).orientation, 'w')
  })
})
