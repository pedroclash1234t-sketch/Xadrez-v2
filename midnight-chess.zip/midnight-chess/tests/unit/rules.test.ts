import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { Chess } from '../../src/engine/chessLib'
import type { Square } from '../../src/engine/chessLib'
import { analyzeChess, analyzeMoves } from '../../src/engine/position'
import { agreeDraw, canPlay, canUndo, canRedo, claimDraw, outcomeOf, playMove, undo, redo } from '../../src/engine/session'
import { FOOLS_MATE, KNIGHT_SHUFFLE, SCHOLARS_MATE, STALEMATE_LINE, newState, play } from './helpers'

const fenOf = (s: { moves: Parameters<typeof analyzeMoves>[0] }) => analyzeMoves(s.moves).fen
const dests = (fen: string, sq: Square) => analyzeChess(new Chess(fen)).dests.get(sq) ?? []

describe('movimentos e alternância de turnos', () => {
  it('posição inicial: brancas jogam, 20 lances legais, peão e2 vai para e3/e4', () => {
    const a = analyzeMoves([])
    assert.equal(a.turn, 'w')
    assert.equal(a.legalMoveCount, 20)
    assert.deepEqual([...(a.dests.get('e2') ?? [])].sort(), ['e3', 'e4'])
    assert.equal(a.outcome, null)
  })

  it('alterna o turno a cada lance legal', () => {
    let s = newState()
    assert.equal(analyzeMoves(s.moves).turn, 'w')
    s = play(s, 'e4')
    assert.equal(analyzeMoves(s.moves).turn, 'b')
    s = play(s, 'e5')
    assert.equal(analyzeMoves(s.moves).turn, 'w')
  })

  it('rejeita lances ilegais sem alterar o estado', () => {
    const s = newState()
    const illegal: Array<[Square, Square]> = [
      ['e2', 'e5'], // peão não anda três casas
      ['b1', 'b3'], // cavalo não anda em linha
      ['e7', 'e5'], // peça do adversário
      ['a1', 'a3'], // torre bloqueada pelo próprio peão
      ['e1', 'e2'], // casa ocupada por peça própria
      ['d1', 'h5'], // dama bloqueada
    ]
    for (const [from, to] of illegal) {
      const r = playMove(s, { from, to })
      assert.deepEqual(r, { ok: false, error: 'illegal' }, `${from}${to} deveria ser ilegal`)
    }
    assert.equal(s.moves.length, 0)
  })

  it('preta não pode abrir; branca não pode jogar duas vezes seguidas', () => {
    const s0 = newState()
    assert.equal(playMove(s0, { from: 'e7', to: 'e5' }).ok, false)
    const s1 = play(s0, 'e4')
    const r = playMove(s1, { from: 'd2', to: 'd4' })
    assert.deepEqual(r, { ok: false, error: 'illegal' })
  })

  it('peça cravada não pode sair da linha do rei', () => {
    const fen = '4k3/4r3/8/8/8/8/4N3/4K3 w - - 0 1'
    assert.deepEqual(dests(fen, 'e2'), [])
  })

  it('rei não pode se mover para casa atacada', () => {
    const fen = '4k3/8/8/8/8/8/r7/4K3 w - - 0 1' // torre preta controla a 2ª fileira
    const kingMoves = dests(fen, 'e1')
    assert.ok(!kingMoves.includes('d2') && !kingMoves.includes('e2') && !kingMoves.includes('f2'))
    assert.ok(kingMoves.includes('d1') && kingMoves.includes('f1'))
  })

  it('em xeque só são aceitos lances que o resolvem', () => {
    const fen = '4k3/8/8/8/8/8/4r3/R3K3 w - - 0 1'
    const a = analyzeChess(new Chess(fen))
    assert.equal(a.inCheck, true)
    assert.deepEqual(a.dests.get('a1'), undefined) // torre não resolve o xeque
    assert.ok(a.dests.get('e1')?.includes('e2')) // rei captura a torre
  })
})

describe('xeque-mate', () => {
  it('mate do pastor: vitória das brancas e partida encerrada', () => {
    const s = play(newState(), ...SCHOLARS_MATE)
    const o = outcomeOf(s)
    assert.deepEqual(o, { result: '1-0', reason: 'checkmate', winner: 'w' })
    assert.equal(analyzeMoves(s.moves).inCheck, true)
    assert.equal(canPlay(s), false)
  })

  it('mate do louco: vitória das pretas', () => {
    const s = play(newState(), ...FOOLS_MATE)
    assert.deepEqual(outcomeOf(s), { result: '0-1', reason: 'checkmate', winner: 'b' })
  })

  it('depois do mate nenhum lance é aceito e o estado não muda', () => {
    const s = play(newState(), ...FOOLS_MATE)
    for (const [from, to] of [['a2', 'a3'], ['e7', 'e6'], ['h4', 'e1']] as Array<[Square, Square]>) {
      const r = playMove(s, { from, to })
      assert.deepEqual(r, { ok: false, error: 'game-over' })
    }
    assert.equal(s.moves.length, 4)
  })

  it('depois do fim não se pode desfazer nem refazer', () => {
    const s = play(newState(), ...FOOLS_MATE)
    assert.equal(canUndo(s), false)
    assert.equal(canRedo(s), false)
    assert.equal(undo(s), s)
    assert.equal(redo(s), s)
  })
})

describe('roque', () => {
  const castle = (fen: string, king: Square) => dests(fen, king)

  it('permitido: pequeno e grande quando livres e seguros', () => {
    const d = castle('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1', 'e1')
    assert.ok(d.includes('g1') && d.includes('c1'))
  })

  it('jogado pela interface: O-O move rei e torre', () => {
    const s = play(newState(), 'e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Bc5')
    const r = playMove(s, { from: 'e1', to: 'g1' })
    assert.ok(r.ok)
    if (r.ok) {
      assert.equal(r.state.moves.at(-1)?.san, 'O-O')
      const board = new Chess(analyzeMoves(r.state.moves).fen)
      assert.equal(board.get('g1')?.type, 'k')
      assert.equal(board.get('f1')?.type, 'r')
    }
  })

  it('proibido: atravessando casa atacada', () => {
    const d = castle('r3k2r/8/8/8/8/8/5r2/R3K2R w KQkq - 0 1', 'e1') // torre preta ataca f1
    assert.ok(!d.includes('g1'))
    assert.ok(d.includes('c1'))
  })

  it('proibido: com o rei em xeque', () => {
    const d = castle('r3k2r/8/8/8/8/8/4r3/R3K2R w KQkq - 0 1', 'e1')
    assert.ok(!d.includes('g1') && !d.includes('c1'))
  })

  it('proibido: depois que o rei já se moveu, mesmo voltando ao lugar', () => {
    const s = play(newState(), 'e4', 'e5', 'Ke2', 'Ke7', 'Ke1', 'Ke8', 'Nf3', 'Nf6', 'Bc4', 'Bc5')
    assert.deepEqual(playMove(s, { from: 'e1', to: 'g1' }), { ok: false, error: 'illegal' })
  })

  it('proibido: com peça entre rei e torre', () => {
    assert.deepEqual(playMove(newState(), { from: 'e1', to: 'g1' }), { ok: false, error: 'illegal' })
  })
})

describe('en passant', () => {
  it('captura imediatamente após o avanço duplo e remove o peão capturado', () => {
    const s = play(newState(), 'e4', 'a6', 'e5', 'd5')
    assert.ok(analyzeMoves(s.moves).dests.get('e5')?.includes('d6'))
    const r = playMove(s, { from: 'e5', to: 'd6' })
    assert.ok(r.ok)
    if (r.ok) {
      assert.equal(r.state.moves.at(-1)?.san, 'exd6')
      const board = new Chess(analyzeMoves(r.state.moves).fen)
      assert.equal(board.get('d5'), undefined)
      assert.equal(board.get('d6')?.type, 'p')
      assert.equal(board.get('d6')?.color, 'w')
    }
  })

  it('perde o direito se não for usado no lance seguinte', () => {
    const s = play(newState(), 'e4', 'a6', 'e5', 'd5', 'h3', 'h6')
    assert.deepEqual(playMove(s, { from: 'e5', to: 'd6' }), { ok: false, error: 'illegal' })
  })
})

describe('promoção', () => {
  const base = () => play(newState(), 'a4', 'b5', 'axb5', 'a6', 'bxa6', 'Nf6', 'a7', 'h6')

  it('exige a escolha da peça e não altera o estado antes disso', () => {
    const s = base()
    assert.deepEqual(playMove(s, { from: 'a7', to: 'b8' }), { ok: false, error: 'promotion-required' })
    assert.equal(s.moves.length, 8)
  })

  it('aceita dama, torre, bispo e cavalo', () => {
    const letters = { q: 'Q', r: 'R', b: 'B', n: 'N' } as const
    for (const p of ['q', 'r', 'b', 'n'] as const) {
      const r = playMove(base(), { from: 'a7', to: 'b8', promotion: p })
      assert.ok(r.ok, `promoção ${p}`)
      if (r.ok) {
        const board = new Chess(analyzeMoves(r.state.moves).fen)
        assert.equal(board.get('b8')?.type, p)
        assert.equal(board.get('b8')?.color, 'w')
        assert.ok(r.state.moves.at(-1)?.san.includes(`=${letters[p]}`))
        assert.equal(r.state.moves.at(-1)?.promotion, p)
      }
    }
  })

  it('rejeita promoção para rei ou peão', () => {
    const bogus = playMove(base(), { from: 'a7', to: 'b8', promotion: 'k' as unknown as 'q' })
    assert.equal(bogus.ok, false)
  })
})

describe('fim de partida: afogamento e empates', () => {
  it('afogamento: empate imediato e partida encerrada', () => {
    const s = play(newState(), ...STALEMATE_LINE)
    assert.deepEqual(outcomeOf(s), { result: '1/2-1/2', reason: 'stalemate' })
    assert.equal(analyzeMoves(s.moves).inCheck, false)
    assert.equal(analyzeMoves(s.moves).legalMoveCount, 0)
    assert.equal(canPlay(s), false)
    assert.deepEqual(playMove(s, { from: 'a2', to: 'a3' }), { ok: false, error: 'game-over' })
  })

  it('material insuficiente: R vs R não, mas K vs K, K+C vs K e K+B vs K+B (mesma cor) sim', () => {
    const reason = (fen: string) => analyzeChess(new Chess(fen)).outcome?.reason
    assert.equal(reason('8/8/8/4k3/8/8/4K3/8 w - - 0 1'), 'insufficient-material')
    assert.equal(reason('8/8/8/4k3/8/8/4KN2/8 w - - 0 1'), 'insufficient-material')
    assert.equal(reason('8/8/4b3/4k3/8/8/4K3/5B2 w - - 0 1'), 'insufficient-material') // bispos em casas da mesma cor
    assert.equal(reason('8/8/8/4k3/8/8/4KR2/8 w - - 0 1'), undefined)
    assert.equal(reason('8/8/8/4k3/8/8/4KNN1/8 w - - 0 1'), undefined) // dois cavalos ainda podem dar mate
  })

  it('repetição tripla é reivindicável: a partida continua até alguém reivindicar', () => {
    const s = play(newState(), ...KNIGHT_SHUFFLE, ...KNIGHT_SHUFFLE)
    const a = analyzeMoves(s.moves)
    assert.equal(a.claim.threefold, true)
    assert.equal(a.outcome, null)
    assert.equal(canPlay(s), true)
    assert.equal(playMove(s, { from: 'e2', to: 'e4' }).ok, true) // pode seguir jogando

    const claimed = claimDraw(s)
    assert.deepEqual(outcomeOf(claimed), { result: '1/2-1/2', reason: 'threefold-claimed' })
    assert.deepEqual(playMove(claimed, { from: 'e2', to: 'e4' }), { ok: false, error: 'game-over' })
  })

  it('duas ocorrências ainda não permitem reivindicar', () => {
    const s = play(newState(), ...KNIGHT_SHUFFLE)
    assert.equal(analyzeMoves(s.moves).claim.threefold, false)
    assert.equal(claimDraw(s), s)
  })

  it('repetição quíntupla encerra a partida automaticamente', () => {
    const four = play(newState(), ...KNIGHT_SHUFFLE, ...KNIGHT_SHUFFLE, ...KNIGHT_SHUFFLE)
    assert.equal(outcomeOf(four), null) // 4ª ocorrência: ainda reivindicável, não automático
    const five = play(four, ...KNIGHT_SHUFFLE)
    assert.deepEqual(outcomeOf(five), { result: '1/2-1/2', reason: 'fivefold-repetition' })
    assert.equal(analyzeMoves(five.moves).claim.threefold, false)
    assert.deepEqual(playMove(five, { from: 'e2', to: 'e4' }), { ok: false, error: 'game-over' })
  })

  it('regra dos 50 lances é reivindicável; a dos 75 é automática', () => {
    const fifty = analyzeChess(new Chess('4k3/8/8/8/8/8/8/R3K3 w - - 100 80'))
    assert.equal(fifty.claim.fiftyMove, true)
    assert.equal(fifty.outcome, null)
    const seventyFive = analyzeChess(new Chess('4k3/8/8/8/8/8/8/R3K3 w - - 150 100'))
    assert.deepEqual(seventyFive.outcome, { result: '1/2-1/2', reason: 'seventy-five-move' })
    assert.equal(seventyFive.claim.fiftyMove, false)
    const early = analyzeChess(new Chess('4k3/8/8/8/8/8/8/R3K3 w - - 99 80'))
    assert.equal(early.claim.fiftyMove, false)
  })

  it('xeque-mate no 75º lance continua sendo vitória, não empate', () => {
    const a = analyzeChess(new Chess('rnb1kbnr/pppp1ppp/8/4p3/6Pq/5P2/PPPPP2P/RNBQKBNR w KQkq - 150 3'))
    assert.deepEqual(a.outcome, { result: '0-1', reason: 'checkmate', winner: 'b' })
  })

  it('empate por acordo encerra a partida', () => {
    const s = agreeDraw(play(newState(), 'e4', 'e5'))
    assert.deepEqual(outcomeOf(s), { result: '1/2-1/2', reason: 'agreement' })
    assert.equal(playMove(s, { from: 'd2', to: 'd4' }).ok, false)
  })

  it('o mesmo resultado que o chess.js informa para a posição final', () => {
    const s = play(newState(), ...SCHOLARS_MATE)
    const lib = new Chess(fenOf(s))
    assert.equal(lib.isCheckmate(), true)
    assert.equal(lib.isGameOver(), true)
  })
})
