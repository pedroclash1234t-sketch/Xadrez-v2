import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { MAX_PGN_CHARS, importPgn } from '../../src/engine/pgnImport'
import { analyzeMoves } from '../../src/engine/position'
import { buildPgn } from '../../src/persistence/record'
import { KEYS } from '../../src/persistence/storage'
import { BLITZ_3_2, MemoryStorage, SCHOLARS_MATE, clockEnv, newState, newStore, play } from './helpers'
import { parseGameRecord } from '../../src/persistence/schema'

const error = (text: string) => {
  const r = importPgn(text)
  assert.equal(r.ok, false, `deveria rejeitar: ${text.slice(0, 60)}`)
  return r.ok ? '' : r.error
}
const good = (text: string) => {
  const r = importPgn(text)
  if (!r.ok) throw new Error(`deveria aceitar, mas: ${r.error}`)
  return r.game
}

describe('importação de PGN: aceita', () => {
  it('o próprio PGN exportado pelo app (ida e volta)', () => {
    const s = play(newState(), ...SCHOLARS_MATE)
    s.players.w = 'Ana'
    s.players.b = 'Beto'
    const g = good(buildPgn(s, { result: '1-0', reason: 'checkmate', winner: 'w' }))
    assert.deepEqual(g.moves, s.moves)
    assert.equal(g.white, 'Ana')
    assert.equal(g.black, 'Beto')
    assert.equal(g.result, '1-0')
    assert.equal(g.startedAt, '2026-10-16T12:00:00.000Z')
  })

  it('PGN "de fora": comentários, variações, NAGs, anotações de lance e quebras de linha', () => {
    const g = good(`[Event "Torneio"]
[White "Magnus"]
[Black "Hikaru"]
[Result "1/2-1/2"]
[Date "2024.03.09"]

1. e4 {abertura} e5 (1... c5 2. Nf3) 2. Nf3 $1 Nc6 3. Bb5! a6
4. Ba4 Nf6 5. O-O Be7 {fim da teoria} 1/2-1/2`)
    assert.deepEqual(g.moves.map((m) => m.san).slice(0, 4), ['e4', 'e5', 'Nf3', 'Nc6'])
    assert.equal(g.moves.length, 10)
    assert.equal(g.result, '1/2-1/2')
    assert.equal(g.white, 'Magnus')
  })

  it('resultado só no marcador do texto, ou só no cabeçalho', () => {
    assert.equal(good('1. e4 e5 2. Nf3 1-0').result, '1-0')
    assert.equal(good('[Result "0-1"]\n\n1. e4 e5 2. Nf3').result, '0-1')
  })

  it('xeque-mate que confere com o resultado informado', () => {
    assert.equal(good('1. f3 e5 2. g4 Qh4# 0-1').result, '0-1')
  })

  it('FEN do cabeçalho idêntico à posição inicial padrão é aceito', () => {
    const fen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'
    assert.equal(good(`[SetUp "1"]\n[FEN "${fen}"]\n[Result "1-0"]\n\n1. e4 e5 1-0`).moves.length, 2)
  })

  it('nomes ausentes ou "?" viram Brancas/Pretas; data incompleta ou impossível é ignorada', () => {
    const g = good('[White "?"]\n[Date "????.??.??"]\n\n1. e4 e5 1-0')
    assert.equal(g.white, 'Brancas')
    assert.equal(g.black, 'Pretas')
    assert.equal(g.startedAt, null)
    assert.equal(good('[Date "2024.02.30"]\n\n1. e4 e5 1-0').startedAt, null)
  })

  it('BOM, espaços e quebras de linha do Windows', () => {
    assert.equal(good('\uFEFF  \r\n[Result "1-0"]\r\n\r\n1. e4 e5\r\n2. Nf3 1-0\r\n').moves.length, 3)
  })

  it('promoção com captura e roque viram os mesmos lances do jogo', () => {
    const promo = good('1. a4 b5 2. axb5 a6 3. bxa6 Nf6 4. a7 h6 5. axb8=N Rxb8 1-0')
    assert.equal(promo.moves[8].san, 'axb8=N')
    assert.equal(promo.moves[8].promotion, 'n')
    const castle = good('1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. O-O Nf6 1-0')
    assert.equal(castle.moves[6].san, 'O-O')
    assert.deepEqual([castle.moves[6].from, castle.moves[6].to], ['e1', 'g1'])
  })
})

describe('importação de PGN: rejeita com mensagem clara', () => {
  it('vazio, só espaços, lixo e limites', () => {
    assert.match(error(''), /Cole o texto/)
    assert.match(error('   \n  '), /Cole o texto/)
    assert.match(error('olá mundo'), /não é um PGN válido/)
    assert.match(error('x'.repeat(MAX_PGN_CHARS + 1)), /grande demais/)
  })

  it('lance ilegal, ambíguo ou depois do xeque-mate', () => {
    assert.match(error('1. e4 e5 2. Ke4 1-0'), /Lance ilegal ou ambíguo no PGN: Ke4/)
    assert.match(error('1. f3 e5 2. g4 Qh4# 3. a3 0-1'), /Lance ilegal ou ambíguo no PGN: a3/)
    assert.match(error('1. e5 1-0'), /Lance ilegal/)
  })

  it('mais de uma partida no texto', () => {
    assert.match(error('[Event "a"]\n\n1. e4 1-0\n\n[Event "b"]\n\n1. d4 0-1'), /mais de uma partida/)
  })

  it('posição inicial personalizada e variantes', () => {
    assert.match(error('[SetUp "1"]\n[FEN "4k3/8/8/8/8/8/4P3/4K3 w - - 0 1"]\n\n1. e4 1-0'), /posição inicial personalizada/)
    assert.match(error('[Variant "Chess960"]\n\n1. e4 e5 1-0'), /variante "Chess960"/)
  })

  it('partida sem resultado, em andamento ou resultado desconhecido', () => {
    assert.match(error('1. e4 e5 2. Nf3'), /não informa o resultado/)
    assert.match(error('[Result "*"]\n\n1. e4 e5 *'), /não informa o resultado/)
    assert.match(error('[Result "1-1"]\n\n1. e4 e5 1-0'), /diferente do marcador/)
  })

  it('cabeçalho e marcador que divergem (o chess.js deixaria o marcador vencer em silêncio)', () => {
    assert.match(error('[Result "1-0"]\n\n1. e4 e5 0-1'), /cabeçalho \(1-0\).*marcador.*\(0-1\)/)
  })

  it('resultado que contradiz a posição final', () => {
    // xeque-mate das pretas, mas o PGN diz que as brancas venceram
    assert.match(error('1. f3 e5 2. g4 Qh4# 1-0'), /xeque-mate.*vitória das pretas.*informa 1-0/)
    assert.match(error('1. e4 e5 2. Qh5 Nc6 3. Bc4 Nf6 4. Qxf7# 1/2-1/2'), /xeque-mate/)
  })

  it('PGN só com cabeçalho (nenhum lance)', () => {
    assert.match(error('[Event "x"]\n[Result "1-0"]\n\n1-0'), /nenhum lance/)
  })
})

describe('importação para o histórico (store)', () => {
  const imported = () => good('[White "Ana"]\n[Black "Beto"]\n[Date "2024.03.09"]\n\n1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 1-0')

  it('entra no histórico como importada, não altera a partida em andamento e não entra nas estatísticas', () => {
    const c = clockEnv()
    const storage = new MemoryStorage()
    const { store } = newStore(storage, c.env)
    store.move('e2', 'e4')
    const currentBefore = storage.getItem(KEYS.current)
    const gameBefore = JSON.stringify(store.getState())

    const r = store.importGame(imported())
    assert.deepEqual(r, { ok: true })
    const snap = store.getSnapshot()
    assert.equal(snap.history.length, 1)
    const rec = snap.history[0]
    assert.equal(rec.source, 'imported')
    assert.equal(rec.reason, 'recorded')
    assert.equal(rec.result, '1-0')
    assert.equal(rec.timeControl, null)
    assert.equal(rec.startedAt, '2024-03-09T12:00:00.000Z')
    assert.match(rec.pgn, /\[Event "Partida importada"\]/)
    assert.deepEqual(snap.stats, { total: 0, whiteWins: 0, blackWins: 0, draws: 0, averageMoves: 0 })
    // a partida jogada continua exatamente como estava, no estado e no disco
    assert.equal(JSON.stringify(store.getState()), gameBefore)
    assert.equal(storage.getItem(KEYS.current), currentBefore)
    assert.equal(snap.canPlay, true)
  })

  it('o registro importado sobrevive a recarregar (passa pela validação)', () => {
    const c = clockEnv()
    const storage = new MemoryStorage()
    const first = newStore(storage, c.env).store
    first.importGame(imported())
    const again = newStore(storage, c.env).store.getSnapshot()
    assert.equal(again.history.length, 1)
    assert.deepEqual(again.history[0], first.getSnapshot().history[0])
    assert.equal(parseGameRecord(JSON.parse(JSON.stringify(again.history[0]))).ok, true)
  })

  it('partida importada que termina em xeque-mate usa o motivo real', () => {
    const { store } = newStore()
    const g = good('[Result "0-1"]\n\n1. f3 e5 2. g4 Qh4# 0-1')
    store.importGame(g)
    assert.equal(store.getSnapshot().history[0].reason, 'checkmate')
  })

  it('a mesma partida não é importada duas vezes; outra partida é', () => {
    const { store } = newStore()
    assert.deepEqual(store.importGame(imported()), { ok: true })
    const again = store.importGame(imported())
    assert.deepEqual(again, { ok: false, error: 'Esta partida já foi importada.' })
    assert.equal(store.getSnapshot().history.length, 1)
    assert.deepEqual(store.importGame(good('1. d4 d5 1-0')), { ok: true })
    assert.equal(store.getSnapshot().history.length, 2)
  })

  it('importar durante uma partida com relógio não mexe no relógio nem na partida', () => {
    const c = clockEnv()
    const storage = new MemoryStorage()
    const { store } = newStore(storage, c.env)
    store.newGame({ w: 'A', b: 'B' }, BLITZ_3_2)
    store.move('e2', 'e4')
    c.advance(5_000)
    const before = JSON.stringify(store.getState())
    store.importGame(imported())
    assert.equal(JSON.stringify(store.getState()), before)
    assert.equal(store.getSnapshot().canLeave, false)
  })

  it('falha ao gravar: informa o erro e não deixa a partida só na memória', () => {
    const storage = new MemoryStorage()
    const { store } = newStore(storage)
    storage.failWrites = true
    const r = store.importGame(imported())
    assert.equal(r.ok, false)
    assert.equal(store.getSnapshot().history.length, 0)
  })

  it('o PGN guardado de uma partida importada é aceito de novo pelo importador', () => {
    const { store } = newStore()
    store.importGame(imported())
    const g = good(store.getSnapshot().history[0].pgn)
    assert.equal(g.result, '1-0')
    assert.equal(g.moves.length, 6)
    assert.equal(analyzeMoves(g.moves).fen, 'r1bqkbnr/1ppp1ppp/p1n5/1B2p3/4P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 0 4')
  })
})
