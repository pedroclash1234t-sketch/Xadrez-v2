// Runs the ORIGINAL chess.js test suite against the vendored copy in vendor/chess.js
// (including the hand-written pgn.ts). The chess.js repository is not bundled here:
//   npm run test:chessjs -- /caminho/para/chess.js-master
// Needs the folder that contains `__tests__/`. Uses a tiny vitest shim (vitest-shim/)
// over node:test, so results are only as faithful as that shim's assertions.
import { cpSync, existsSync, mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { spawnSync } from 'node:child_process'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..')
const repo = process.argv[2] ?? process.env.CHESSJS_REPO
if (!repo || !existsSync(join(repo, '__tests__'))) {
  console.error('Uso: npm run test:chessjs -- <pasta do repositório chess.js que contém __tests__>')
  process.exit(2)
}

const work = mkdtempSync(join(tmpdir(), 'chessjs-upstream-'))
try {
  mkdirSync(join(work, 'src'))
  for (const f of ['chess.ts', 'node.ts', 'pgn.ts']) cpSync(join(root, 'vendor/chess.js', f), join(work, 'src', f))
  cpSync(join(repo, '__tests__'), join(work, '__tests__'), { recursive: true })
  cpSync(join(root, 'tests/upstream-chessjs/vitest-shim'), join(work, 'node_modules/vitest'), { recursive: true })
  writeFileSync(join(work, 'package.json'), '{ "type": "commonjs" }\n')
  const tsx = join(root, 'node_modules/.bin/tsx')
  const r = spawnSync(tsx, ['--test', '--test-reporter=spec', '__tests__/*.test.ts'], { cwd: work, stdio: 'inherit' })
  process.exitCode = r.status ?? 1
} finally {
  rmSync(work, { recursive: true, force: true })
}
